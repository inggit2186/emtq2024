<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UsersBerkas extends Model
{
    use HasFactory;

	protected $table = 'users_berkas';

    protected $fillable = [   
        'user_id',
        'no_req',
		'layanan_id',
        'syarat_id',
        'filename',
        'filetype',
        'size',
		'status'
    ];
	
	public function user(){
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
	public function request(){
        return $this->belongsTo(UsersRequest::class, 'req_id', 'id');
    }
	public function syarat(){
        return $this->belongsTo(Syarat::class, 'syarat_id', 'id');
    }
}
