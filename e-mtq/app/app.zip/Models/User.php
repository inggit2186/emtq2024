<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Tymon\JWTAuth\Contracts\JWTSubject;

class User extends Authenticatable implements JWTSubject
{
    use HasFactory, Notifiable;
    
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }
    public function getJWTCustomClaims()
    {
        return [];
    }

    public function tanggapan(){
        return $this->hasMany(tanggapan::class, 'user_id', 'id');
    }
	public function to_tanggapan(){
        return $this->hasMany(tanggapan::class, 'to_user', 'id');
    }
	public function usersrequest(){
        return $this->hasMany(UsersRequest::class, 'user_id', 'nomor_induk');
    }
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
		'id',
		'username',
        'name',
        'email',
        'password',
		'nomor_induk',
        'tempat_lahir',
        'tanggal_lahir',
		'pekerjaan',
		'telp',
		'alamat',
        'role',
		'dept_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
}
