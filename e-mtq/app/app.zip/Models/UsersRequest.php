<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UsersRequest extends Model
{
    use HasFactory;

	protected $table = 'users_request';

    protected $fillable = [   
        'no_req',
        'user_id',
        'dept_id',
        'layanan_id',
        'judul',
        'deskripsi',
        'staff_id',
        'status'
    ];
	
	public function tanggapan(){
        return $this->hasOne(Tanggapan::class, 'no_req', 'no_req');
    }
	public function user(){
        return $this->belongsTo(User::class, 'user_id', 'nomor_induk');
    }
	public function dept(){
        return $this->belongsTo(Department::class, 'dept_id', 'id');
    }
	public function layanan(){
        return $this->belongsTo(Layanan::class, 'layanan_id', 'id');
    }
	public function staff(){
        return $this->belongsTo(User::class, 'staff_id', 'id');
    }
}
