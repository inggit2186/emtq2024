<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use Illuminate\Http\Request;
use Auth;
use App\Models\CMTQ;
use App\Models\GMTQ;
use App\Models\Nilai;
use App\Models\Peserta;
use App\Models\PesertaSemifinal;
use App\Models\PesertaFinal;
use App\Models\Bidang;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Storage;
use Telegram\Bot\Laravel\Facades\Telegram;

class SiteController extends Controller
{
    public function index()
    {
        return view('frontend.index');
    }
	public function cover()
    {
        return view('frontend.cover');
    }
    // input pengaduan
	public function cmtq()
    {
        return view('frontend.subbagian', [
			'gmtq' => GMTQ::where('user_id', Auth::user()->id)->groupBy('cmtq_id')->get(),
		]);
    }
	
	public function score()
    {
		$user = Auth::user()->name;
		
		if( Auth::user()->role == 'user'){
			$peserta = Peserta::with(['cmtq', 'gmtq'])->where('operator',$user)->latest()->first();
		}else{
			$peserta = Peserta::with(['cmtq', 'gmtq'])->latest()->first();
		}
		
			$nilai = Nilai::with(['cmtq','gmtq','bidang','peserta'])->where('peserta',$peserta->nama)->get();
			
        return view('frontend.score', [
			'cmtq' => CMtq::all(),
			'peserta' => $peserta,
			'nilai' => $nilai,
		]);
    }
	
	public function ranking()
    {
        return view('frontend.ranking', [
			'cmtq' => GMTQ::where('user_id', Auth::user()->id)->groupBy('cmtq_id')->get(),
		]);
    }
	
	public function rankingmtq($id)
    {
		$cid = Crypt::decrypt($id);
        return view('frontend.rankingmtq', [
			'cmtq' => CMtq::findOrfail(Crypt::decrypt($id)),
			'gmtq' => GMtq::with('cmtq')->where(['cmtq_id' => $cid,'user_id' => Auth::user()->id])->get(),
			'gmtq2' => GMtq::with('cmtq')->where(['cmtq_id' => $cid,'user_id' => Auth::user()->id])->get(),
		]);
    }
	
	public function deleterank($id)
    {
		$pid = Crypt::decrypt($id);
        $peserta = Peserta::findOrfail($pid);
		$nilaip = Nilai::where('peserta',$peserta->nama)->delete();
		$peserta->delete();
		return redirect()->back()->with('status', 'Data Nilai berhasil dihapus :D');
    }
	
	public function editrank($id)
    {
		$pid = Crypt::decrypt($id);
        $peserta = Peserta::findOrfail($pid);
		$nilaip = Nilai::with(['cmtq','gmtq','peserta','bidang'])->where('peserta',$peserta->nama)->groupBy('bidang_id')->get();
		return view('frontend.editnilai', [
			'peserta' => $peserta,
			'nilai' => Bidang::with('cmtq')->where('cat_id',$peserta->kategori_id)->get(),
			'nilaip' => $nilaip,
			'pid' => $pid,
		]);
    }
	
	public function editstore(Request $request)
    {	
		$date = date('Ymd',strtotime("now"));
		$dept_id = $request->cid;
		$gid = $request->gid;
		$vtotal = 0;
		$nilai = Bidang::with('cmtq')->where('cat_id',$dept_id)->get();
		
		$xtotal=0;
		$nilaip = Nilai::where('peserta', $request->dnama)->delete();
		
		foreach($nilai as $nilai){
		$i=0;
		$jhakim=0;
		$total = 0;
			for($i=0;$i < $nilai->hakim;$i++){
				$hakim[$i] = $request->input('hakim'.$nilai->id.'-'.$i) ?? NULL;
				
				if($hakim[$i] != NULL){
					$jhakim=$jhakim+1;
				}
				
				$bidang = $nilai->id;
				$xnilai[$i] = $request->input('nilai'.$nilai->id.'-'.$i) ?? NULL;
				$penanya = $request->penanya ?? NULL;
				
				$total = $total+$xnilai[$i];
				
				Nilai::create([
					'peserta' => $request->nama,
					'kategori_id' => $request->cid,
					'golongan_id' => $request->gid,
					'status' => 0,
					'penanya' => $penanya,
					'hakim' => $hakim[$i],
					'nilai' => $xnilai[$i],
					'bidang_id' => $bidang,
					]);
			}
				
				$vtotal = round(($total/$jhakim),2);
				Nilai::where('bidang_id',$nilai->id)->orderBy('id','desc')
						->take(1)->update(['total' => $vtotal]);
				
				$xtotal = $xtotal+$vtotal;
		}
		
		
		Peserta::where('id',$request->id)->update([
			'nama' => $request->nama,
			'nomor' => $request->nomor,
			'kategori_id' => $request->cid,
			'golongan_id' => $request->gid,
			'total' => $xtotal,
			'operator' => Auth::user()->name,
		]);
		
		$cid = Crypt::Encrypt($request->cid);
        return redirect()->route('ranking.mtq',$cid)->with('status', 'Data Nilai berhasil Dirubah :D');;
    }
	
    public function create($id)
    {
		$deptid = Crypt::decrypt($id);
        $data = [
            'title' => 'Input Nilai',
			'cmtq' => CMtq::findOrfail(Crypt::decrypt($id)),
            'gmtq' => GMtq::with('cmtq')->where(['cmtq_id' => $deptid, 'user_id' => Auth::user()->id])->get(),
            'nilai' => Bidang::with('cmtq')->where('cat_id',$deptid)->get(),
            'nilai2' => Bidang::with('cmtq')->where('cat_id',$deptid)->get(),
            'nilai3' => Bidang::with('cmtq')->where('cat_id',$deptid)->get(),
        ];
        //return view('frontend.input-pengaduan');
		return view('frontend.input-pengaduan', $data);
    }
	
    // storer
    public function store(Request $request, $id)
    {
        // action to store data request into database
        if($request->gid == 0){
		$request->validate([
            'nama' => 'required|unique:mtq_peserta',
            'nomor' => 'unique:mtq_peserta',
            'jlayanan' => 'required',
            'gid' => 'required',
        ]);
		}elseif($request->gid == 1){
			$request->validate([
            'nama' => 'required|unique:mtq_peserta_semifinal',
			'nomor' => 'unique:mtq_peserta',
            'jlayanan' => 'required',
            'gid' => 'required',
        ]);
		}else{
			$request->validate([
            'nama' => 'required|unique:mtq_peserta_final',
			'nomor' => 'unique:mtq_peserta',
            'jlayanan' => 'required',
            'gid' => 'required',
        ]);
		}
		
		$date = date('Ymd',strtotime("now"));
		$dept_id = $id;
		$gid = $request->jlayanan;
		$vtotal = 0;
		$nilai = Bidang::with('cmtq')->where('cat_id',$dept_id)->get();
		
		$xtotal=0;
		foreach($nilai as $nilai){
		$i=0;
		$jhakim=0;
		$total = 0;
			for($i=0;$i < $nilai->hakim;$i++){
				$hakim[$i] = $request->input('hakim'.$nilai->id.'-'.$i) ?? NULL;
				
				if($hakim[$i] != NULL){
					$jhakim=$jhakim+1;
				}
				
				$bidang = $nilai->id;
				$xnilai[$i] = $request->input('nilai'.$nilai->id.'-'.$i) ?? NULL;
				$penanya = $request->penanya ?? NULL;
				
				$total = $total+$xnilai[$i];
				
				Nilai::create([
					'peserta' => $request->nama,
					'kategori_id' => $id,
					'golongan_id' => $request->jlayanan,
					'status' => $request->gid,
					'penanya' => $request->penanya,
					'hakim' => $hakim[$i],
					'nilai' => $xnilai[$i],
					'bidang_id' => $bidang,
					]);
			}
				
				$vtotal = round(($total/$jhakim),2);
				Nilai::where('bidang_id',$nilai->id)->orderBy('id','desc')
						->take(1)->update(['total' => $vtotal]);
				
				$xtotal = $xtotal+$vtotal;
		}
		
		if( $request->gid == 0 ){
		 Peserta::create([
			'nama' => $request->nama,
			'nomor' => $request->nomor,
			'kategori_id' => $id,
			'golongan_id' => $request->jlayanan,
			'total' => $xtotal,
			'operator' => Auth::user()->name,
		]);
		}elseif( $request->gid == 1 ){
		 PesertaSemifinal::create([
			'nama' => $request->nama,
			'nomor' => $request->nomor,
			'kategori_id' => $id,
			'golongan_id' => $request->jlayanan,
			'total' => $xtotal,
			'operator' => Auth::user()->name,
		]);
		}else{
		 PesertaFinal::create([
			'nama' => $request->nama,
			'nomor' => $request->nomor,
			'kategori_id' => $id,
			'golongan_id' => $request->jlayanan,
			'total' => $xtotal,
			'operator' => Auth::user()->name,
		]);
		}
		
        return redirect()->route('success');
    }

    public function handleDetail($id = false)
    {
        $dec = \Crypt::Decrypt($id);
        return view('frontend.detail-pengaduan', [
            'groupItem' => UsersRequest::with(['user', 'tanggapan', 'layanan'])->where('id', $dec)->first()
        ]);
    }

    public function handleSearch(Request $request)
    {
		return view('frontend.cek-pengaduan', [
            'groupItem' => UsersRequest::with(['dept', 'user', 'layanan'])->where('user_id', (auth()->user()->nomor_induk))
						->whereRelation('layanan', 'nama', 'like', '%' . $request->keyword . '%')
						->orWhere('judul', 'like', '%' . $request->keyword . '%')
						->orWhere('no_req', 'like', '%' . $request->keyword . '%')
						->orWhere('deskripsi', 'like', '%' . $request->keyword . '%')
						->latest()
						->paginate(3)
        ]);
    }

    public function handleCheck(Request $request)
    {
		//return view('frontend.cek-pengaduan', ['user_request' => UsersRequest::where('user_id', auth()->user()->nomor_induk)->paginate(3)]);
    
        return view('frontend.cek-pengaduan', [
            'groupItem' => UsersRequest::with(['dept', 'user', 'layanan'])->where('user_id', (auth()->user()->nomor_induk))->latest()->paginate(3)
        ]);
	}

    // sukses page
    public function success()
    {
        return view('frontend.sukses');
    }

    public function destroy($id)
    {
        UsersRequest::destroy($id);
        Activity::create([
            'activity' => Auth::user()->name . ' menghapus Request/Konsultasi/Pengaduan dengan no.Reg:',
        ]);
        return redirect()->route('pengaduan.check')->with('status', 'Data Berhasil Dihapus');
    }
}
