-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2022 at 11:24 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Database: `mtq`
--

-- --------------------------------------------------------

--
-- Table structure for table `cat_bidang`
--

CREATE TABLE `cat_bidang` (
  `id` int(255) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `cat_id` int(100) NOT NULL,
  `nilai` int(11) NOT NULL,
  `hakim` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cat_bidang`
--

INSERT INTO `cat_bidang` (`id`, `nama`, `cat_id`, `nilai`, `hakim`) VALUES
(1, 'Tajwid', 1, 30, 3),
(2, 'Fashahah', 1, 30, 3),
(3, 'Suara dan Lagu', 1, 40, 3),
(4, 'Tajwid', 4, 30, 2),
(5, 'Fashahah', 4, 30, 2),
(6, 'Suara dan Lagu', 4, 40, 2),
(7, 'Hafalan / Tahfiz', 3, 50, 1),
(8, 'Tajwid', 3, 25, 1),
(9, 'Fashahah', 3, 25, 1),
(10, 'Hafalan', 5, 50, 1),
(11, 'Mufradat', 5, 25, 1),
(12, 'Penafsiran/Penguraian/Kesimpulan', 5, 25, 1),
(13, 'Tilawah', 8, 30, 3),
(14, 'Terjemahan & Materi', 8, 30, 2),
(15, 'Syarhil', 8, 40, 2),
(16, 'Adzan', 9, 40, 2),
(17, 'Ayat & Hadis', 9, 30, 2),
(18, 'Materi', 9, 30, 2),
(19, 'Qira\'at', 10, 40, 1),
(20, 'Terjemahan', 10, 30, 1),
(21, 'Pengambilan Hukum/Kesimpulan', 10, 30, 1),
(22, 'Fashahah', 12, 25, 1),
(23, 'Tajwid', 12, 25, 1),
(24, 'Tahfiz', 12, 50, 1),
(25, 'Fashahah', 13, 25, 1),
(26, 'Tajwid', 13, 25, 1),
(27, 'Tahfiz', 13, 50, 1),
(28, 'Nilai Akhir', 7, 5000, 1),
(29, 'Tajwid', 2, 30, 2),
(30, 'Fashahah', 2, 30, 2),
(31, 'Suara dan Lagu', 2, 40, 2);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_01_26_054535_create_pengaduans_table', 1),
(5, '2021_01_26_060120_add_role_to_users_table', 1),
(6, '2021_01_28_120550_create_tanggapans_table', 1),
(7, '2021_02_03_062306_create_activities_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mtq_category`
--

CREATE TABLE `mtq_category` (
  `id` int(25) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `penanya` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mtq_category`
--

INSERT INTO `mtq_category` (`id`, `kategori`, `penanya`) VALUES
(1, 'Seni Baca Alqur\'an', 0),
(2, 'Qira\'at Al Qur\'an', 0),
(3, 'Hafalan Alqur\'an', 1),
(4, 'Tartil Alqur\'an', 0),
(5, 'Tafsir Alqur\'an', 1),
(6, 'Seni Kaligrafi Alqur\'an', 0),
(7, 'Fahmil Alqur\'an', 0),
(8, 'Syarhil Al Qur\'an', 0),
(9, 'Khubah Jum\'at dan Adzan', 0),
(10, 'Kitab Standar', 0),
(11, 'Karya Tulis Ilmiah Al Qur\'an', 0),
(12, 'Hafalan Hadist/500 Hadist Tanpa Sanad', 0),
(13, 'Hafalan Hadist/500 Hadist dengan Sanad', 0);

-- --------------------------------------------------------

--
-- Table structure for table `mtq_golongan`
--

CREATE TABLE `mtq_golongan` (
  `id` int(100) NOT NULL,
  `golongan` varchar(255) NOT NULL,
  `cmtq_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mtq_golongan`
--

INSERT INTO `mtq_golongan` (`id`, `golongan`, `cmtq_id`) VALUES
(1, 'Tilawah Kanak-kanak', 1),
(2, 'Tilawah Anak-Anak', 1),
(3, 'Tilawah Remaja', 1),
(4, 'Tilawah Dewasa', 1),
(5, 'Tilawah Lansia', 1),
(6, 'Qira\'at Mujawwad Dewasa', 2),
(7, 'Qira\'at Muratal Remaja', 2),
(8, 'Qira\'at Muratal Dewasa', 2),
(9, 'HQ.1 Juz Tilawah', 3),
(10, 'HQ.5 Juz Tilawah', 3),
(11, 'HQ. 1 Juz Non Tilawah', 3),
(12, 'HQ. 5 Juz Non Tilawah', 3),
(13, 'HQ.10 Juz', 3),
(14, 'HQ.30 Juz', 3),
(15, 'Tartil Dasar', 4),
(16, 'Tartil Menengah', 4),
(17, 'Tartil Umum', 4),
(18, 'Tafsir Bahasa Arab', 5),
(19, 'Tafsir Bahasa Indonesia', 5),
(20, 'Tafsir Bahasa Inggris', 5),
(21, 'Khaligrafi Naskah', 6),
(22, 'Khaligrafi Mushaf', 6),
(23, 'Khaligrafi Dekorasi', 6),
(24, 'Khaligrafi Kontemporer', 6),
(26, 'Musabaqoh Syarhil Qur\'an (MSQ)', 8),
(27, 'Khutbah Jum\'at dan Adzan', 9),
(29, 'Kitab Standar', 10),
(30, 'Karya Tulis Ilmiah Al Qur\'an', 11),
(31, 'Hafalan Hadist/500 Hadist Tanpa Sanad', 12),
(32, 'Hafalan Hadist/500 Hadist Dengan Sanad', 13),
(33, 'Musabaqoh Fahmil Qur\'an (MFQ)', 7);

-- --------------------------------------------------------

--
-- Table structure for table `mtq_nilai`
--

CREATE TABLE `mtq_nilai` (
  `id` int(11) NOT NULL,
  `peserta` varchar(255) NOT NULL,
  `kategori_id` int(11) NOT NULL,
  `golongan_id` int(11) NOT NULL,
  `status` int(255) DEFAULT NULL,
  `penanya` varchar(255) DEFAULT NULL,
  `hakim` varchar(255) DEFAULT NULL,
  `bidang_id` int(100) DEFAULT NULL,
  `nilai` int(255) DEFAULT NULL,
  `total` float DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mtq_nilai`
--

INSERT INTO `mtq_nilai` (`id`, `peserta`, `kategori_id`, `golongan_id`, `status`, `penanya`, `hakim`, `bidang_id`, `nilai`, `total`, `created_at`, `updated_at`) VALUES
(276, 'Kec.Lintau Buo', 7, 33, 0, NULL, 'dkk', 28, 1300, 1300, '2022-06-14 08:06:14', '2022-06-14 08:06:14'),
(287, 'Ridho Saputra', 1, 1, 0, NULL, 'Hakim 001', 1, 29, NULL, '2022-06-17 16:00:09', '2022-06-17 16:00:09'),
(288, 'Ridho Saputra', 1, 1, 0, NULL, 'Hakim 002', 1, 30, NULL, '2022-06-17 16:00:09', '2022-06-17 16:00:09'),
(289, 'Ridho Saputra', 1, 1, 0, NULL, 'Hakim 003', 1, 30, 29.64, '2022-06-17 16:00:09', '2022-06-17 16:00:09'),
(290, 'Ridho Saputra', 1, 1, 0, NULL, 'Fs 001', 2, 30, NULL, '2022-06-17 16:00:09', '2022-06-17 16:00:09'),
(291, 'Ridho Saputra', 1, 1, 0, NULL, 'Fs 002', 2, 30, NULL, '2022-06-17 16:00:09', '2022-06-17 16:00:09'),
(292, 'Ridho Saputra', 1, 1, 0, NULL, 'Fs 003', 2, 29, 29.55, '2022-06-17 16:00:10', '2022-06-17 16:00:10'),
(293, 'Ridho Saputra', 1, 1, 0, NULL, 'Sl 001', 3, 39, NULL, '2022-06-17 16:00:10', '2022-06-17 16:00:10'),
(294, 'Ridho Saputra', 1, 1, 0, NULL, 'Sl 002', 3, 38, NULL, '2022-06-17 16:00:10', '2022-06-17 16:00:10'),
(295, 'Ridho Saputra', 1, 1, 0, NULL, 'Sl 003', 3, 38, 38.35, '2022-06-17 16:00:10', '2022-06-17 16:00:10');

-- --------------------------------------------------------

--
-- Table structure for table `mtq_peserta`
--

CREATE TABLE `mtq_peserta` (
  `id` int(100) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `nomor` varchar(255) NOT NULL,
  `kategori_id` int(100) NOT NULL,
  `golongan_id` int(100) NOT NULL,
  `total` float NOT NULL,
  `operator` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mtq_peserta`
--

INSERT INTO `mtq_peserta` (`id`, `nama`, `nomor`, `kategori_id`, `golongan_id`, `total`, `operator`, `created_at`, `updated_at`) VALUES
(41, 'Kec.Lintau Buo', '2', 7, 33, 1300, 'Gusni Yetti, S.AP', '2022-06-14 08:06:14', '2022-06-14 08:06:14'),
(44, 'Ridho Saputra', 'H.Q 002', 1, 1, 97.54, 'Ridho Saputra S.Kom', '2022-06-17 16:00:10', '2022-06-17 16:00:10');

-- --------------------------------------------------------

--
-- Table structure for table `mtq_peserta_final`
--

CREATE TABLE `mtq_peserta_final` (
  `id` int(100) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `nomor` int(255) NOT NULL,
  `kategori_id` int(100) NOT NULL,
  `golongan_id` int(100) NOT NULL,
  `total` float NOT NULL,
  `operator` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `mtq_peserta_semifinal`
--

CREATE TABLE `mtq_peserta_semifinal` (
  `id` int(100) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `nomor` int(255) NOT NULL,
  `kategori_id` int(100) NOT NULL,
  `golongan_id` int(100) NOT NULL,
  `total` float NOT NULL,
  `operator` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tempat_lahir` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `pekerjaan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nomor_induk` bigint(255) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` enum('user','admin','frontdesk','kasubbag','kepala','kasi','petugas') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'petugas',
  `dept_id` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `username`, `password`, `telp`, `alamat`, `tempat_lahir`, `tanggal_lahir`, `pekerjaan`, `nomor_induk`, `remember_token`, `created_at`, `updated_at`, `role`, `dept_id`) VALUES
(1, 'Administrator', 'admin@ptsp.com', NULL, '', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, 'lima kaum', '2022-04-21', 'Pranata Komputer', 1006240, NULL, '2022-04-20 23:26:07', '2022-04-20 23:26:07', 'admin', 101),
(111, 'Misrawati, A.Md', '198407182009012004', NULL, '198407222009011009', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Arsiparis', 198407222009011009, NULL, NULL, NULL, 'user', 1),
(112, 'Taufik Edwarsya, S.Sos', '198604262005011001', NULL, '198604262005011001', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Analisi Pengelola Keuangan', 198604262005011001, NULL, NULL, NULL, 'user', 1),
(113, 'Yusral', '196905102007011067', NULL, '196905102007011067', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Analis Pengembangan SDM Aparatur', 196905102007011067, NULL, NULL, NULL, 'user', 1),
(114, 'Rika Syafrina S.Sos', '197611152006042001', NULL, '197611152006042001', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Pranata Keuangan', 197611152006042001, NULL, NULL, NULL, 'user', 1),
(115, 'Zawil Husaini, S.Ag', '197602281997031003', NULL, '197602281997031003', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Analis Perencana Evaluasi dan Pelaporan', 197602281997031003, NULL, NULL, NULL, 'user', 1),
(116, 'M.Ridwan', '198104142014111002', NULL, '198104142014111002', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Pengelola BMN', 198104142014111002, NULL, NULL, NULL, 'user', 1),
(117, 'Emilia Rizaldy, SE', '198303142022012007', NULL, '198303142022012007', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Penyusun Laporan Keuangan', 198303142022012007, NULL, NULL, NULL, 'user', 1),
(118, 'Gusni Yetti, S.AP', '197708252007012021', NULL, '197708252007012021', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Bendahara Pengeluaran', 197708252007012021, NULL, NULL, NULL, 'user', 1),
(119, 'Rina Hastati, S.Sos', '197910182007102001', NULL, '197910182007102001', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Penyusun Laporan Keuangan', 197910182007102001, NULL, NULL, NULL, 'user', 1),
(120, 'Joni Roza, S.Ag', '197606082007011034', NULL, '197606082007011034', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Penyusun Dokumen Haji', 197606082007011034, NULL, NULL, NULL, 'user', 1),
(121, 'Alwandris, S.Pd.I', '198109052007101001', NULL, '198109052007101001', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Penyusun Bahan Pendaftaran dan Pembatalan Jamaah Haji', 198109052007101001, NULL, NULL, NULL, 'user', 1),
(122, 'Roky Ardinal, S.Sos, M.Pd', '197710191998031001', NULL, '197710191998031001', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Analis Kapasitas Pendidik dan Siswa', 197710191998031001, NULL, NULL, NULL, 'user', 1),
(123, 'Bahrul Fahmi, S.AP', '197709052009011012', NULL, '197709052009011012', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Pengevaluasi Keuangan', 197709052009011012, NULL, NULL, NULL, 'user', 1),
(124, 'Rina Susanti, SE', '197801052009122004', NULL, '197801052009122004', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Analis Data dan Informasi Pendidik dan Tenaga Kependidikan', 197801052009122004, NULL, NULL, NULL, 'user', 1),
(125, 'Yusneti', '198604172009012006', NULL, '198604172009012006', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Analis Kapasitas Pendidik dan Santri', 198604172009012006, NULL, NULL, NULL, 'user', 1),
(126, 'Ridho Saputra S.Kom', '199201152022031001', NULL, '199201152022031001', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Pranata Komputer', 199201152022031001, NULL, NULL, NULL, 'user', 1),
(128, 'Adri Eka Putra, S.Pd.I', '198307222009011009', NULL, '198307222009012004', '$2y$10$ygMyuvO0AyvR.FCRNjjOJeW3EIbN63LpjtmioS9uN6iwxB02sQCNa', NULL, NULL, NULL, NULL, 'Analis Kepegawaian', 198307222009012004, NULL, NULL, NULL, 'admin', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cat_bidang`
--
ALTER TABLE `cat_bidang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtq_category`
--
ALTER TABLE `mtq_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtq_golongan`
--
ALTER TABLE `mtq_golongan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtq_nilai`
--
ALTER TABLE `mtq_nilai`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtq_peserta`
--
ALTER TABLE `mtq_peserta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtq_peserta_final`
--
ALTER TABLE `mtq_peserta_final`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mtq_peserta_semifinal`
--
ALTER TABLE `mtq_peserta_semifinal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_nomor_induk_unique` (`nomor_induk`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cat_bidang`
--
ALTER TABLE `cat_bidang`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `mtq_category`
--
ALTER TABLE `mtq_category`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `mtq_golongan`
--
ALTER TABLE `mtq_golongan`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `mtq_nilai`
--
ALTER TABLE `mtq_nilai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=296;

--
-- AUTO_INCREMENT for table `mtq_peserta`
--
ALTER TABLE `mtq_peserta`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `mtq_peserta_final`
--
ALTER TABLE `mtq_peserta_final`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `mtq_peserta_semifinal`
--
ALTER TABLE `mtq_peserta_semifinal`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;
COMMIT;
