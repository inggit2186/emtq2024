<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>



<?php $__env->startSection('title','Request Layanan | Kantor Kemenag Tanah Datar'); ?>
<?php $__env->startSection('content'); ?>

<style>
label {
	font-size: 18px;
	font-weight: 500;
}

table, tr, td {
  border: 1px solid white;
  border-collapse: collapse;
}
tr, td {
  background-color: #96D4D4;
}
</style>
<section class="w-full px-8 py-20 bg-gray-100 xl:px-8">
    <div class="max-w-5xl mt-20  mx-auto">
        <div class="flex flex-col justify-between items-center md:flex-row">
            <div class="w-full mt-16 md:mt-0 ">
                <form action="<?php echo e(route('edit.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div
                        class="w-full h-auto p-10 py-10 overflow-hidden bg-white border-b-2 border-gray-300 rounded-lg shadow-2xl px-7">
                        <h3 class="mb-6 text-2xl font-medium text-center">Edit <strong>Penilaian</strong>
                        </h3>
						<input type=hidden name="id" value="<?php echo e($peserta->id); ?>" />
						<input type=hidden name="cid" value="<?php echo e($peserta->kategori_id); ?>" />
						<input type=hidden name="gid" value="<?php echo e($peserta->golongan_id); ?>" />
						<input type=hidden name="dnama" value="<?php echo e($peserta->nama); ?>" />
						<label for="" class="text-gray-600">Sesi / Babak</label>
						<div class="block mb-4 border <?php $__errorArgs = ['jenis_pengaduan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-gray-200 rounded-lg">
							<input type="text" name="nama" id="nama" required
                                class="block w-full <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none" 
								value="Penyisihan"readonly />
                        </div>
						<br />
						<br />
						<label for="" class="text-gray-600">Jenis Golongan</label>
                        <div class="block mb-4 border <?php $__errorArgs = ['jenis_pengaduan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-gray-200 rounded-lg">
							<input type="text" name="nama" id="nama" required
                                class="block w-full <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none" 
								value="<?php echo e($peserta->gmtq->golongan); ?>" readonly />
                        </div>
                        <?php $__errorArgs = ['jlayanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-600 mb-4" style="background-color: yellow;"><?php echo e($message); ?></div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					   
                        <label for="" class="text-gray-600">Nama Peserta / Grup</label>
                        <div class="block mb-4 border border-gray-200 rounded-lg">
                            <input type="text" name="nama" id="nama" required
                                class="block w-full <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none"
                                value="<?php echo e($peserta->nama); ?>" >
                        </div>
                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-600 mb-4" style="background-color: yellow;"><?php echo e($message); ?></div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="" class="text-gray-600">Nomor Loot</label>
                        <div class="block mb-4 border <?php $__errorArgs = ['nomor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-gray-200 rounded-lg">
                            <input type="text" name="nomor" id="nomor"
                                class="block w-full px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none" 
								value="<?php echo e($peserta->nomor); ?>" />
                        </div>
                        <?php $__errorArgs = ['nomor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-600 mb-4" style="background-color: yellow;"><?php echo e($message); ?></div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						<br /><br />
						<?php if($peserta->cmtq->penanya == 1): ?>
						<?php
							$penanya = App\Models\Nilai::where('peserta',$peserta->nama)->whereNotNull('penanya')->groupBy('penanya')->first();
						?>
						<label for="" class="text-gray-600">Hakim Penanya</label>
                        <div class="block mb-4 border <?php $__errorArgs = ['penanya'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-gray-200 rounded-lg">
                            <input type="text" name="penanya" id="penanya"
                                value="<?php echo e($penanya->penanya); ?>" class="block w-full px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none" />
                        </div>
                        <?php $__errorArgs = ['penanya'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-600 mb-4" style="background-color: yellow;"><?php echo e($message); ?></div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					   <?php endif; ?>
					   <br />
						<?php $a=0; ?>
						<?php $__currentLoopData = $nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $i=0; ?>
							<table>
							<thead>
								<tr><td colspan=3><label for="" class="text-gray-600">&nbsp;&nbsp;<b><?php echo e($nilai->nama); ?></b></label></td></tr>
							</thead>
							<tbody>
							<?php for($i==0;$i < $nilai->hakim;$i++): ?>
								<?php
									$value = App\Models\Nilai::where(['peserta' => $peserta->nama, 'bidang_id' => $nilai->id])->skip($i)->first();
								?>
								<tr>
								<td style="width:80%;"><input list="hakim" type="text" name="hakim<?php echo e($nilai->id); ?>-<?php echo e($i); ?>" id="nilai" 
                                class="block w-full <?php $__errorArgs = ['nhakim1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none" autocomplete="off" 
								value="<?php if(!empty($value->hakim)): ?><?php echo e($value->hakim); ?><?php endif; ?>" placeholder="Nama Hakim <?php echo e($i+1); ?>" />
    							<datalist id="hakim">
    							    <?php $lhakim = App\Models\Nilai::where('kategori_id',$peserta->kategori_id)->groupBy('hakim')->get();
    							    ?>
    							    <?php $__currentLoopData = $lhakim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lhakim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    							        <option value="<?php echo e($lhakim->hakim); ?>" />
    							    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    							</datalist>
                                </td>
								<td><input type="number" step="any" name="nilai<?php echo e($nilai->id); ?>-<?php echo e($i); ?>" id="xnilai" max="<?php echo e($nilai->nilai); ?>"
                                class="block w-full <?php $__errorArgs = ['nilai<?php echo e($nilai->id); ?>-<?php echo e($i); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none" 
                                value="<?php if(!empty($value->nilai)): ?><?php echo e($value->nilai); ?><?php endif; ?>" 
								placeholder="Nilai" /></td><td align="center">(Max)<br/><?php echo e($nilai->nilai); ?></td>
								</tr>
							<?php endfor; ?>
							</tbody>
							</table>
							<br /><br />
							<?php $a++; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					   
					   <br />
					   <br />

							<div class="block">
								<button type="submit"
								class="w-full px-3 py-4 font-medium font-semibold font-medium text-white bg-blue-600 rounded-lg">Kirim</button>
							</div>
                </form>
            </div>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-mtq\resources\views/frontend/editnilai.blade.php ENDPATH**/ ?>