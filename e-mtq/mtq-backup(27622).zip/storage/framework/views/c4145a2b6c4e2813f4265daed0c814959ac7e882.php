
<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<div class="page-heading">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>Data Nomor Loot Peserta</h3>
                <p class="text-subtitle text-muted"><b>Restricted Access</b></p>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Data Loot</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <section class="section">
        <div class="card">
            <div class="card-body">
                <form class="form form-horizontal" action="<?php echo e(route('cek.loot')); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <div class="row">
                            
							<div class="col-md-4">
                                <label>Pilih Kategori</label>
                            </div>
                            <div class="col-md-8 form-group">
                                <select id="cmtq" class="form-control <?php $__errorArgs = ['cmtq'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('cmtq')); ?>" name="cmtq" >
								<option value="Pilihdulu" disabled selected
                                    class="block w-full px-4 py-3 border-2 border-transparent text-gray-400 rounded-lg focus:border-blue-500 focus:outline-none">
                                    ---- Pilih Kategori ------</option>
								<?php $__currentLoopData = $cmtq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmtq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($cmtq->id); ?>"
                                    class="block w-full px-4 py-3 border-2 border-transparent text-gray-800 rounded-lg focus:border-blue-500 focus:outline-none">
                                    <?php echo e($cmtq->kategori); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								
                                <?php $__errorArgs = ['cmtq'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <i class="bx bx-radio-circle"></i>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
							<div class="col-md-4">
                                <label>Pilih Cabang</label>
                            </div>
                            <div class="col-md-8 form-group">
                                <select id="gmtq" class="form-control <?php $__errorArgs = ['cmtq'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('gmtq')); ?>" name="gmtq" >
								
								</select>
								
                                <?php $__errorArgs = ['gmtq'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <i class="bx bx-radio-circle"></i>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="col-sm-12 d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary me-1 mb-1">Cek Loot</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </section>
</div>

<script>
jQuery(document).ready(function(){
  $("#cmtq").change(function() {
	 var cmtq = $(this).val();
		
      var url = "<?php echo e(route('cekno.cabang', '')); ?>" + "/" + cmtq;
	  console.log(url);
	  
	  $.ajax({
	   type:'GET',
	   url:url,
	   data:{"_token": "<?php echo e(csrf_token()); ?>"},
	   dataType: "json",
	   success:function(data){ 
                $('#gmtq').empty();
                $("#gmtq").append('<option>--Pilih Cabang--</option>');
                if(data)
                {
                    $.each(data,function(key,value){
                        $('#gmtq').append($("<option/>", {
                           value: value.id,
                           text: value.golongan
                        }));
                    });
                }
	   }});
	   
  });
    
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-mtq\resources\views/backend/pages/DataLoot/index.blade.php ENDPATH**/ ?>