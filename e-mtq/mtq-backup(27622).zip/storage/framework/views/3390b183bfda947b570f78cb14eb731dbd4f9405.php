
<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>Detail Request</h3>
                <p class="text-subtitle text-muted">Detail Request</p>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('pengaduan')); ?>">Pengaduan</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Detail Pengaduan</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <section class="section">
        <div class="card">
            <div class="card-body">
                <div>
                    <h4>Informasi User</h4>
                    <table>
                        <tr>
                            <td width="180px">Nomor Induk</td>
                            <td>:</td>
                            <td><?php echo e($laporan->user->nomor_induk); ?></td>
                        </tr>
                        <tr>
                            <td>Nama</td>
                            <td>:</td>
                            <td><?php echo e($laporan->user->name); ?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td>:</td>
                            <td><?php echo e($laporan->user->email); ?></td>
                        </tr>
                        <tr>
                            <td>Nomor Telepon</td>
                            <td>:</td>
                            <td><?php echo e($laporan->user->no_telp); ?></td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td><?php echo e($laporan->user->alamat); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="mt-4">
                    <h4>Laporan</h4>
                    <table>
                        <tr>
                            <td width="180px">No.Registrasi</td>
                            <td>:</td>
                            <td><?php echo e($laporan->no_req); ?></td>
                        </tr>
                        <tr>
                            <td>Departemen</td>
                            <td>:</td>
                            <td><?php echo e($laporan->dept->nama); ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal Masuk</td>
                            <td>:</td>
                            <td><?php echo e($laporan->created_at->format('d/m/Y')); ?></td>
                        </tr>
                        <tr>
                            <td>Layanan / Judul</td>
                            <td>:</td>
                            <?php if(!empty($laporan->judul)): ?>
								<td><?php echo e($laporan->judul); ?></td>
							<?php else: ?>
								<td><?php echo e($laporan->layanan->nama); ?></td>
							<?php endif; ?>
                        </tr>
                        <tr>
                            <td>Deskripsi</td>
                            <td>:</td>
                            <td><?php echo e($laporan->deskripsi); ?></td>
                        </tr>
                        <tr>
                            <td>Berkas Pendukung</td>
                            <td>:</td>
                            <td>
                                <?php if($laporan->berkas_pendukung): ?>
                                    <?php echo e($laporan->berkas_pendukung); ?>

                                    <a href="<?php echo e(asset($laporan->berkas_pendukung)); ?>" download="<?php echo e($laporan->berkas_pendukung); ?>" class="btn btn-primary"><i class="fas fa-download"></i></a>
                                <?php else: ?>
                                Tidak ada berkas
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
					<br />
					<p style="font-size:14px"><i> Status : <?php if($laporan->status === 'PENDING'): ?>
                                    <?php echo e($laporan->status); ?>

                                <?php elseif($laporan->status === 'DITOLAK'): ?>
                                    <?php echo e($laporan->status); ?> oleh auth()->user()->role
                                <?php elseif($laporan->status === 'SUKSES'): ?>
                                    <?php echo e($laporan->status); ?> 
                                <?php elseif($laporan->status === 'BATAL'): ?>
                                    <?php echo e($laporan->status); ?> 
								<?php elseif($laporan->status === 'DITERIMA'): ?>
									<?php if($laporan->staff->role == 'kasi'): ?> 
										<?php echo e($laporan->status); ?> oleh <?php echo e($laporan->staff->pekerjaan); ?>

									<?php else: ?>
										<?php echo e($laporan->status); ?> oleh <?php echo e($laporan->staff->pekerjaan); ?>

									<?php endif; ?>
								<?php elseif($laporan->status === 'DIPROSES'): ?>
									DIPROSES oleh Staff <?php echo e($laporan->dept->nama); ?>

								<?php endif; ?> </i><br />
					<i> Last Update <?php echo e($laporan->updated_at->format('d/m/Y-H:i:s')); ?> </i></p>
					
                </div>
				<br />
            <!--    <div class="mt-4">
                    <h4>Status</h4>
                    <?php if($laporan->status === 'sukses'): ?>
                        <button class="btn btn-outline-success">Laporan Diterima</button>
                        <div class="mt-4">
                            Tanggapan : 
                            <p><?php echo e($laporan->tanggapan->tanggapan); ?></p><?php echo e($laporan->tanggapan->user->name); ?>

                        </div>
                    <?php elseif($laporan->status === 'ditolak'): ?>
                        <button class="btn btn-outline-danger">Laporan Ditolak</button>
                        <div class="mt-4">
                            Tanggapan : 
                            <p><?php echo e($laporan->tanggapan->tanggapan); ?></p><?php echo e($laporan->tanggapan->user->name); ?>

                        </div>
                    <?php else: ?>
                        <a href="<?php echo e(route('tanggapan',  Crypt::Encrypt($laporan->id))); ?>" class="btn btn-primary">Tanggapi</a>
                    <?php endif; ?>
                </div>
			-->
			</div>
			<div class="card-body">
				<div class="row">
					<div class="col-12 col-md-6 order-md-1 order-last">
						<h3>Update Status</h3>
						<p class="text-subtitle text-muted">Form Tanggapan Staff</p>
					</div>
				</div>
			<section class="section">
				<div class="card">
					<div class="card-body">
					<?php if(Auth::user()->role == 'admin'): ?>
						<form action="<?php echo e(route('store.tanggapan', $laporan->id)); ?>" method="post">
							<?php echo csrf_field(); ?>
							<div class="form-group mb-3">
								<label for="tanggapan" class="form-label">Tanggapan</label>
								<textarea class="form-control <?php $__errorArgs = ['tanggapan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tanggapan" id="tanggapan" rows="3"></textarea>
								<?php $__errorArgs = ['tanggapan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<div class="invalid-feedback">
										<i class="bx bx-radio-circle"></i>
										<?php echo e($message); ?>

									</div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
							<div class="form-check form-check-inline">
								<input class="form-check-input" type="radio" name="status" id="inlineRadio1" value="DITERIMA">
								<label class="form-check-label text-success" for="inlineRadio1">Diterima</label>
							</div>
							<div class="form-check form-check-inline">
								<input class="form-check-input" type="radio" name="status" id="inlineRadio1" value="DIPROSES">
								<label class="form-check-label text-success" for="inlineRadio1">Diproses</label>
							</div>
							<div class="form-check form-check-inline">
								<input class="form-check-input" type="radio" name="status" id="inlineRadio1" value="SUKSES">
								<label class="form-check-label text-success" for="inlineRadio1">Selesei / Sukses</label>
							</div>
							<div class="form-check form-check-inline">
								<input class="form-check-input" type="radio" name="status" id="inlineRadio1" value="DITOLAK">
								<label class="form-check-label text-success" for="inlineRadio1">Ditolak</label>
							</div>
							<div class="form-check form-check-inline">
								<input class="form-check-input" type="radio" name="status" id="inlineRadio2" value="BATAL">
								<label class="form-check-label text-danger" for="inlineRadio2">Batal</label>
							</div>
							<?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="text-danger">
									<i class="bx bx-radio-circle"></i>
									<span><?php echo e($message); ?></span>
								</div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							<div class="col-sm-12 d-flex justify-content-end">
								<button type="submit" class="btn btn-primary me-1 mb-1">Submit</button>
							</div>
						</form>
					<?php endif; ?>
					</div>
				</div>

			</section>
		</div>
		</div>
    </section>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ptsp.kemenag\resources\views/backend/pages/pengaduan/detail.blade.php ENDPATH**/ ?>