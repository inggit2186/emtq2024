<div id="sidebar" class="active">
    <div class="sidebar-wrapper active">
        <div class="sidebar-header">
            <div class="d-flex justify-content-between">
                <div class="logo">
                    <a href="<?php echo e(url('/panel')); ?>"><img src="<?php echo e(asset('backend/images/logo/logo.png')); ?>" alt="Logo" srcset=""></a>
                </div>
                <div class="toggler">
                    <a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
                </div>
            </div>
        </div>
        <div class="sidebar-menu">
            <ul class="menu">
                <li class="sidebar-title">Menu</li>

                <li class="sidebar-item<?php echo e(request()->is('panel') ? ' active' : ''); ?>">
                    <a href="<?php echo e(route('dashboard')); ?>" class='sidebar-link'>
                        <i class="bi bi-grid-fill"></i>
                        <span>Dashboard</span>
                    </a>
                </li>

                <?php if(Auth::user()->role ==='admin'): ?>
                <li class="sidebar-item  has-sub<?php echo e(request()->is('panel/masterdata/*') ? ' active' : ''); ?>">
                    <a href="#" class='sidebar-link'>
                        <i class="fas fa-database"></i>
                        <span>Master Data</span>
                    </a>
                    <ul class="submenu<?php echo e(request()->is('panel/masterdata/*') ? ' active' : ''); ?>">
                        <li class="submenu-item<?php echo e(request()->is('panel/masterdata/petugas*') ? ' active' : ''); ?>">
                            <a href="<?php echo e(route('data.petugas')); ?>">Data Admin</a>
                        </li>
                        <li class="submenu-item<?php echo e(request()->is('panel/masterdata/users*') ? ' active' : ''); ?>">
                            <a href="<?php echo e(route('data.users')); ?>">Data Operator</a>
                        </li>
						<li class="submenu-item<?php echo e(request()->is('panel/masterdata/cabang*') ? ' active' : ''); ?>">
                            <a href="<?php echo e(route('data.cabang')); ?>">Data Cabang</a>
                        </li>
						<li class="submenu-item<?php echo e(request()->is('panel/masterdata/loot*') ? ' active' : ''); ?>">
                            <a href="<?php echo e(route('data.loot')); ?>">Data Loot</a>
                        </li>
						<li class="submenu-item<?php echo e(request()->is('panel/masterdata/activity*') ? ' active' : ''); ?>">
                            <a href="<?php echo e(route('data.activity')); ?>">Data Aktifitas</a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>
                
                <li class="sidebar-item  has-sub<?php echo e(request()->is('panel/penilaian/*') ? ' active' : ''); ?>">
                    <a href="#" class='sidebar-link'>
                        <i class="fas fa-database"></i>
                        <span>Data Penilaian</span>
                    </a>
                    <ul class="submenu<?php echo e(request()->is('panel/penilaian/*') ? ' active' : ''); ?>">
                        <li class="submenu-item<?php echo e(request()->is('panel/penilaian/penyisihan*') ? ' active' : ''); ?>">
                            <a href="<?php echo e(route('panel.cmtq')); ?>">Babak Penyisihan</a>
                        </li>
                        <li class="submenu-item<?php echo e(request()->is('panel/penilaian/final*') ? ' active' : ''); ?>">
                            <a href="<?php echo e(route('panelfinal.cmtq')); ?>">Babak Final</a>
                        </li>
                    </ul>
                </li>

                <li class="sidebar-item<?php echo e(request()->is('panel/pengaduan') ? ' active' : ''); ?>">
                    <form action="<?php echo e(route('proses.logout')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-block"> <i class="fas fa-sign-out-alt mt-2"></i> Logout</button>
                    </form>
                </li>

            </ul>
        </div>
        <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
    </div>
</div><?php /**PATH /home/kemenagt/public_html/mtq/resources/views/backend/layout/sidebar.blade.php ENDPATH**/ ?>