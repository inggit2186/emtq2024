<link rel="icon" href="<?php echo e(asset('assets/favicon.png')); ?>">
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">

<style>
@import  url(https://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100);


body {
  background-image: url(https://cdna.artstation.com/p/assets/images/images/005/152/718/large/nikita-kozlov-123.jpg?1488878117);
  background-position: center; /* Center the image */
  background-repeat: no-repeat; /* Do not repeat the image */
  background-size: cover;
  
}

.container-fluid {
    width: 90%;
}
.title {
    font-size: 5vw;
    text-align: center;
    padding: 30px;
}
td {
    cursor: pointer;
    text-align: center;
}
img.pp {
  border-radius: 50%;
  width: 90px;
  height: 90px;
}
img.pp2 {
  border-radius: 50%;
  padding: 10px;
  width: 160px;
  height: 160px;
}
img.web {
  padding: 10px;
  width: 60px;
  height: 60px;
}


.table:hover tbody tr:hover td {
    background-color: grey;
}



* {
  font-family: Roboto;
}

h2{
  font-weight: 100;
  font-size: 30pt;
  line-height: 1.3em;
  margin: 15px 0;
}

div.message {
  position: relative;
  padding: 10px;
  padding-left: 35px;
  margin: 30px 10px;
  box-shadow:0 2px 5px rgba(0,0,0,.3);
  background: #BBB;
  color: #FFF;
  
  -webkit-transition: all .5s ease;
     -moz-transition: all .5s ease;
      -ms-transition: all .5s ease;
       -o-transition: all .5s ease;
          transition: all .5s ease;
}
div.message:hover{
  box-shadow: 0 15px 20px rgba(10,0,10,.3);
  -webkit-filter: brightness(110%);
}

div.message:before{
  content: '';
  font-family: FontAwesome;
  position: absolute;
  display: block;
  top: -21px;
  left: 50%;
  margin:0 -21px;
  font-size: 20px;
  line-height: 24px;
  text-align: center;
  width: 24px;
  padding:10px;
  background: inherit;
  box-shadow:0 5px 10px rgba(0,0,0,.25);
  color: rgba(255,255,255,.75);
  border-radius:50%;
  border: 2px solid transparent;
  z-index: 2;
}

div.message.information:before{content:'\f129';}
div.message.announcement:before{content:'\f0f3';}
div.message.success:before{content:'\f00c';}
div.message.warning:before{content:'\f12a';}
div.message.error:before{content:'\f00d';}

div.message.information{background: #39B;}
div.message.warning{background: #E74;}
div.message.success{background: #5A6;}
div.message.announcement{background: #EA0;}


/* Style the tab */
.tab {
  overflow: hidden;
  text-align:center;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
}

/* Style the buttons that are used to open the tab content */
.tab button {
  background-color: #ddd;
  float: center;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 19px;
  font-weight:800;
  font-family: Roboto;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ccc;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: yellow;
}

/* Style the tab content */
.tabcontent {
  display: none;
  text-align:center;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
}
</style>

<html>
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<body>
<!DOCTYPE html>
<html>
<head>
    <title>Rekap MTQ ke-41 Kab.Tanah Datar</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
  
<body>
  <div class="container">
    
    <div class="information message" align="center">
		<h1>Informasi</h1>
		<h3><p>Daftar Rekap Hasil MTQ Nasional ke-41 Kab.Tanah Datar</h3> </p>
		<h3><p>Kategori <?php echo e($cmtq->kategori); ?></p></h3> 
	</div>
	
    <?php if(session('error')): ?>
	<div class="information message" align="center">
		<h3><?php echo e(session('error')); ?></h3>		
	</div>
	<?php endif; ?>
	<?php if(session('status')): ?>
	<div class="information message" align="center">
		<h3><?php echo e(session('status')); ?></h3>		
	</div>
	<?php endif; ?>
	
	<div class="tab">
	<?php $__currentLoopData = $gmtq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gmtq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<button class="tablinks" onclick="openCity(event, '<?php echo e($gmtq->id); ?>')"><?php echo e($gmtq->golongan); ?></button>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	
	<?php $a=0; ?>
	<?php $__currentLoopData = $gmtq2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gmtq2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php
		$i=1;
		if($cmtq->id == 7){
		$peserta = App\Models\Peserta::with(['cmtq','gmtq'])->where('golongan_id',$gmtq2->id)->orderBy('total','DESC')->get()->sortBy('nomor');
		}else{
		$peserta = App\Models\Peserta::with(['cmtq','gmtq'])->where('golongan_id',$gmtq2->id)->orderBy('total', 'DESC')->get();
		}
		$bidang = App\Models\Bidang::with(['cmtq'])->where('cat_id',$cmtq->id)->get();
	?>
	<div id="<?php echo e($gmtq2->id); ?>" class="tabcontent" <?php if($a==0): ?> style="display:block;" <?php endif; ?>>
		<h3><?php echo e($gmtq2->golongan); ?></h3>
		<div class="row">
      <div class="col-md-12 col-xs-12">
        <table id="table1" class="table table-striped table-bordered">
          <thead>
            <tr>
              <th style="text-align: center;">Rank</th>
              <th style="text-align: center;">Nama Peserta</th>
			  <?php if($cmtq->id == 7): ?>
			  <th style="text-align: center;">Nomor Loot</th>
			  <?php endif; ?>
			  <?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bidang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <th style="text-align: center;"><?php echo e($bidang->nama); ?></th>
			  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <th style="text-align: center;">Total Nilai</th>
              <th style="text-align: center;">Opsi</th>
            </tr>
          </thead>
          <tbody>
			<?php $__currentLoopData = $peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php 
				$nilai = App\Models\Nilai::with(['cmtq','gmtq','bidang','peserta'])->where('peserta',$peserta->nama)->get();
			?>
			<tr>
				<td><?php echo e($i); ?></td>
				<td><?php echo e($peserta->nama); ?></td>
				<?php if($cmtq->id == 7): ?>
				<td style="text-align: center;"><?php echo e($peserta->nomor); ?></td>
				<?php endif; ?>
				<?php $__currentLoopData = $nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($nilai->total != NULL): ?>
					<td><?php echo e($nilai->total); ?></td>
				<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<td><?php echo e($peserta->total); ?></td>
				<td><a href="<?php echo e(route('edit.rank', Crypt::Encrypt($peserta->id))); ?>" class="badge bg-warning" style="font-size: 15px; color:black;" onclick="modal()">EDIT</a> &nbsp; <a href="<?php echo e(route('delete.rank', Crypt::Encrypt($peserta->id))); ?>" class="badge bg-danger" onclick="return confirm('Anda Yakin Untuk Menghapus?')" style="font-size: 15px; color:black;">DELETE</a></td>
			<?php $i++; ?>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>       
        </table>
      </div>   
    </div>  
	</div>
	<?php $a++; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
  </div>

</html>
</body>
</html>

<script>
function openCity(evt, cityName) {
  // Declare all variables
  var i, tabcontent, tablinks;

  // Get all elements with class="tabcontent" and hide them
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Get all elements with class="tablinks" and remove the class "active"
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  // Show the current tab, and add an "active" class to the button that opened the tab
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
  
</script>
<?php /**PATH C:\xampp\htdocs\e-mtq\resources\views/frontend/rankingmtq.blade.php ENDPATH**/ ?>