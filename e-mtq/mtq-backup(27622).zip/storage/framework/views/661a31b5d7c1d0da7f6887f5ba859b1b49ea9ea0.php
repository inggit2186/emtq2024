
<?php $__env->startSection('content'); ?>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">

<style>
#syaratUser tr {
	text-align: center;
}
#syaratUser td {
	text-align: center;
}
#syaratUser th{
	text-align: center;
	height: 40px;
	font-size: 20px;
}
}
</style>


<html>
<div class="page-heading">
    <h3>Dashboard</h3>
</div>
<div class="page-content">
    <section class="row">
        <div class="col-12 col-lg-9">
            <div class="row">
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body px-3 py-4-5">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="stats-icon purple">
                                        <i class="iconly-boldShow"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold">Aktivitas User</h6>
                                    <h6 class="font-extrabold mb-0">112.000</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body px-3 py-4-5">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="stats-icon blue">
                                        <i class="iconly-boldProfile"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold">Data User</h6>
                                    <h6 class="font-extrabold mb-0">183.000</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body px-3 py-4-5">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="stats-icon green">
                                        <i class="iconly-boldAdd-User"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold">Data Petugas</h6>
                                    <h6 class="font-extrabold mb-0">80.000</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3 col-md-6">
                    <div class="card">
                        <div class="card-body px-3 py-4-5">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="stats-icon red">
                                        <i class="iconly-boldBookmark"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold">Data Permintaan</h6>
                                    <h6 class="font-extrabold mb-0">112</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<div class="card">
            <div class="card-body">
                <?php if(session('status')): ?>
                    <div class="alert alert-success mt-1">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <table class="table table-striped" id="table1">
                    <thead>
                        <tr>
                            <th>No.Registrasi</th>
                            <th>Departemen</th>
                            <th>Layanan / Judul</th>
                            <th>Tgl.Masuk</th>
                            <th>Status</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $groupItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if((Auth::user()->id == $item->staff_id || Auth::user()->dept_id == 101 || Auth::user()->dept_id == 104) && ($item->status == "PENDING" || $item->status == "DITERIMA" || $item->status == "DIPROSES")): ?>
						
                        <tr>
						<!-- DATA USER YANG REQUEST -->
							<td style="display:none;"><?php echo e($item->user->id); ?></td>
							<td style="display:none;"><?php echo e($item->user->name); ?></td>
							<td style="display:none;"><?php echo e($item->user->email); ?></td>
							<td style="display:none;"><?php echo e($item->user->telp); ?></td>
							<td style="display:none;"><?php echo e($item->user->pekerjaan); ?></td>
							<td style="display:none;"><?php echo e($item->user->alamat); ?></td>
							
						<!-- DATA REQUEST -->
                            <td><?php echo e($item->no_req); ?></td>
                            <td><?php echo e($item->dept->nama); ?></td>
							<?php if(!empty($item->judul)): ?>
								<td><?php echo e($item->judul); ?></td>
							<?php else: ?>
								<td><?php echo e($item->layanan->nama); ?></td>
							<?php endif; ?>
							<td>
								<?php echo e($item->created_at->format('d/m/Y')); ?>

							</td>
							<td style="display:none;"><?php echo e($item->deskripsi); ?></td>
                            <td>
                                 <?php if($item->status === 'PENDING'): ?>
                                    <span class="badge bg-warning"><?php echo e($item->status); ?></span>
                                <?php elseif($item->status === 'DITOLAK'): ?>
                                    <span class="badge bg-danger"><?php echo e($item->status); ?></span>
                                <?php elseif($item->status === 'SUKSES'): ?>
                                    <span class="badge bg-primary"><?php echo e($item->status); ?></span>
                                <?php elseif($item->status === 'BATAL'): ?>
                                    <span class="badge bg-dark"><?php echo e($item->status); ?></span>
								<?php elseif($item->status === 'DITERIMA'): ?>
									<span class="badge bg-secondary"><?php echo e($item->status); ?></span>
								<?php elseif($item->status === 'DIPROSES'): ?>
									<span class="badge bg-success"><?php echo e($item->status); ?></span>
								<?php endif; ?>
                            </td>
                            <td>
                                <a href="#" class="badge bg-info">DETAIL</a>
                            </td>
							
							<!-- DATA TAMBAHAN (YANG TERLUPAKAN) -->
							<td style="display:none;"><?php echo e($item->dept_id); ?></td>
							<td style="display:none;">Status : <?php if($item->status === 'PENDING'): ?>
                                    <?php echo e($item->status); ?>

                                <?php elseif($item->status === 'DITOLAK'): ?>
                                    <?php echo e($item->status); ?> oleh auth()->user()->role
                                <?php elseif($item->status === 'SUKSES'): ?>
                                    <?php echo e($item->status); ?> 
                                <?php elseif($item->status === 'BATAL'): ?>
                                    <?php echo e($item->status); ?> 
								<?php elseif($item->status === 'DITERIMA'): ?>
									<?php if($item->staff->role == 'kasi'): ?> 
										<?php echo e($item->status); ?> oleh <?php echo e($item->staff->pekerjaan); ?>

									<?php elseif($item->staff->role == 'petugas'): ?>
										DITUGASKAN kepada <?php echo e($item->staff->name); ?> ( <?php echo e($item->staff->pekerjaan); ?> )
									<?php else: ?>
										<?php echo e($item->status); ?> oleh <?php echo e($item->staff->pekerjaan); ?>

									<?php endif; ?>
								<?php elseif($item->status === 'DIPROSES'): ?>
									DIPROSES oleh oleh <?php echo e($item->staff->name); ?> ( <?php echo e($item->staff->pekerjaan); ?> )
								<?php endif; ?></td>
							<td style="display:none;">Last Update <?php echo e($item->updated_at->format('d/m/Y-H:i:s')); ?></td>
							<td style="display:none;"><?php echo e($item->status); ?></td>
							<td style="display:none;"><?php echo e($item->staff_id); ?></td>
							<td style="display:none;"><?php echo e(Auth::user()->id); ?></td>
							<td style="display:none;"><?php echo e(Auth::user()->dept_id); ?></td>
							
                        </tr>
						<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Log Aktivitas User  </h4>
                        </div>
                        <div class="card-body">
                            <table class="table">
                                <tr>
                                    <th width="10%">#</th>
                                    <th width="75%">Activity</th>
                                    <th width="15%">Time</th>
                                </tr>
                                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->activity); ?></td>
                                        <td><?php echo e($item->created_at->diffForHumans()); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-xl-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Admin & Staff</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover table-lg">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Comment</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="col-3">
                                                <div class="d-flex align-items-center">
                                                    <div class="avatar avatar-md">
                                                        <img src="backend/images/faces/5.jpg">
                                                    </div>
                                                    <p class="font-bold ms-3 mb-0">Staff 1</p>
                                                </div>
                                            </td>
                                            <td class="col-auto">
                                                <p class=" mb-0">Congratulations on your graduation!</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="col-3">
                                                <div class="d-flex align-items-center">
                                                    <div class="avatar avatar-md">
                                                        <img src="backend/images/faces/2.jpg">
                                                    </div>
                                                    <p class="font-bold ms-3 mb-0">Staff 2</p>
                                                </div>
                                            </td>
                                            <td class="col-auto">
                                                <p class=" mb-0">Wow amazing design! Can you make another
                                                    tutorial for
                                                    this design?</p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-3">
            <div class="card">
                <div class="card-body py-4 px-5">
                    <div class="d-flex align-items-center">
                        <div class="avatar avatar-xl">
                            <img src="backend/images/faces/1.jpg" alt="Face 1">
                        </div>
                        <div class="ms-3 name">
                            <h5 class="font-bold"><?php echo e(Auth::user()->name); ?></h5>
                            <h6 class="text-muted mb-0">@ <?php echo e(Auth::user()->name); ?></h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h4>Recent Messages</h4>
                </div>
                <div class="card-content pb-4">
                    <div class="recent-message d-flex px-4 py-3">
                        <div class="avatar avatar-lg">
                            <img src="backend/images/faces/4.jpg">
                        </div>
                        <div class="name ms-4">
                            <h5 class="mb-1">Staff 1</h5>
                            <h6 class="text-muted mb-0">@kemenagStaff1</h6>
                        </div>
                    </div>
                    <div class="recent-message d-flex px-4 py-3">
                        <div class="avatar avatar-lg">
                            <img src="backend/images/faces/5.jpg">
                        </div>
                        <div class="name ms-4">
                            <h5 class="mb-1">Staff 2</h5>
                            <h6 class="text-muted mb-0">@kemenagStaff2</h6>
                        </div>
                    </div>
                    <div class="recent-message d-flex px-4 py-3">
                        <div class="avatar avatar-lg">
                            <img src="backend/images/faces/1.jpg">
                        </div>
                        <div class="name ms-4">
                            <h5 class="mb-1">Staff 3</h5>
                            <h6 class="text-muted mb-0">@kemenagStaff3</h6>
                        </div>
                    </div>
                    <div class="px-4">
                        <button class='btn btn-block btn-xl btn-light-primary font-bold mt-3'>Start
                            Conversation</button>
                    </div>
                </div>
            </div>
            
        </div>
    </section>
</div>


<!-- Modal -->
       <div id="myModal" class="modal fade" role="dialog" style="max-height: 100%;max-width:100%; overflow-y: auto; overflow-x: auto;">
          <div class="modal-dialog">
            <div class="modal-content" style="width:450px;">
              <!-- Modal header -->
              <div id="name" class="modal-header" style="justify-content: center;text-align:center;" >
                <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
			  
              <!-- Modal body -->
              <div id="ModalBody" class="modal-body"></div>
			  <center><tr colspan=2><td colspan=2> <button class="badge bg-primary" onclick="showSyarat()">CEK SYARAT-SYARAT BERKAS</button></td></tr></center>
			  
			  <div id="syaratUser" style="display:none;">
				<table class="table table-striped">
					<thead>
					<tr>
						<th>Syarat</th>
						<th>Opsi</th>
					</tr>
					</thead>
					<tbody id="sy1"></tbody>
				</table>
			  </div>
			  
			  <div class="modal-body" id="ModalEnding">
					<center><tr><td colspan=2><p><h5><u> Tanggapan </u></h5></p></td></tr>
					<form id="postman" action="" method='POST'>
					<?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
						<input type="hidden" id="deptid" name="deptid" value="">
						<input type="hidden" id="deptname" name="deptname" value="">
						<input type="hidden" id="laynname" name="laynname" value="">
						<input type="hidden" id="noreq" name="noreq" value="">
						<input type="hidden" id="userid" name="userid" value="">
						<tr colspan=2><td colspan=2><textarea name="tanggapan" id="tanggapan" style="height:90px;width:100%;"></textarea></td></tr></center>
						<?php if(Auth::user()->role == 'kasi'): ?>
						<p style="font-size:12px"><i>SETUJU = Tanggapan akan dikirim ke Staff Selanjutnya<br />
						TOLAK = Tanggapan akan dikirim ke User/Pengguna yang mengajukan</i></p>
							<center><tr><td colspan=2><p><h6><u> Staff yang akan Ditugaskan </u></h6></p></td></tr>
							<select name="staff" id="staff"
                                class="block w-full px-2 py-2 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none"
								style="text-align:center; max-width:350px;" required>
                                <option value="" disabled selected
                                    class="block w-full px-2 py-2 border-2 border-transparent text-gray-400 rounded-lg focus:border-blue-500 focus:outline-none">
                                    ---- Silahkan Pilih Staff ------</option>
								<?php $__currentLoopData = $Staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value='<?php echo e($staff->id); ?>' 
                                    class="block w-full px-2 py-2 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none">
                                    <?php echo e($staff->name); ?>&nbsp;|&nbsp;<?php echo e($staff->pekerjaan); ?></option>
								</center>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
						<br />
						<br />
						<center><tr colspan=2><td colspan=2> <button class="badge bg-primary" type="SUBMIT" name="action" value="setuju">SETUJUI</button>&nbsp; &nbsp;<button class="badge bg-dark" type="SUBMIT" name="action" value="tolak">TOLAK</button></td></tr></center>
						
						<?php elseif(Auth::user()->role == 'petugas'): ?>
						<p style="font-size:12px"><i>Tanggapan akan dikirim ke User/Pengguna yang mengajukan</i></p>
						<center><tr colspan=2><td colspan=2> 
							<button class="badge bg-primary" type="SUBMIT" name="action" value="proses" id="bproses">DIPROSES</button>&nbsp; &nbsp;
							<button class="badge bg-warning" type="SUBMIT" name="action" value="sukses" id="bsukses">SUKSES</button>&nbsp; &nbsp;
							<button class="badge bg-dark" type="SUBMIT" name="action" value="tolak" id="btolak">TOLAK</button>&nbsp; &nbsp;
							<button class="badge bg-danger" type="SUBMIT" name="action" value="batal" id="bbatal">BATAL</button>&nbsp; &nbsp;
							</td></tr></center>
						
						<?php else: ?>
						<p style="font-size:12px"><i>SETUJU = Tanggapan akan dikirim ke Staff Selanjutnya<br />
						TOLAK = Tanggapan akan dikirim ke User/Pengguna yang mengajukan</i></p>
						<center><tr colspan=2><td colspan=2> <button class="badge bg-primary" type="SUBMIT" name="action" value="setuju">SETUJUI</button>&nbsp; &nbsp;<button class="badge bg-dark" type="SUBMIT" name="action" value="tolak">TOLAK</button></td></tr></center>	
						<?php endif; ?>
					</form>
			  </div>
              <!-- Modal footer -->
			  <div class="modal-footer">
			  <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
</html>

<script>

$(document).ready(function(){ 
  $("#table1 tbody tr td").click(function(){
    $("#myModal").modal('show');
    document.getElementById('syaratUser').style.display = 'none';
	
	var getData = $(this).closest('tr');
	  var user_id = getData.children()[0].textContent;
	  var nama = getData.children()[1].textContent;
	  var email  = getData.children()[2].textContent;
	  var telp  = getData.children()[3].textContent;
	  var pekerjaan  = getData.children()[4].textContent;
	  var alamat  = getData.children()[5].textContent;
	  
	  var no_req = getData.children()[6].textContent;
	  var department = getData.children()[7].textContent;
	  var layanan  = getData.children()[8].textContent;
	  var tglmasuk  = getData.children()[9].textContent;
	  var deskripsi  = getData.children()[10].textContent;
	  
	  var deptid  = getData.children()[13].textContent;
	  var status  = getData.children()[14].textContent;
	  var lastupdate  = getData.children()[15].textContent;
	  var status2  = getData.children()[16].textContent;
	  var staff  = getData.children()[17].textContent;
	  var cstaff  = getData.children()[18].textContent;
	  var frontdesk  = getData.children()[19].textContent;
	
	  var url = "<?php echo e(route('update.layanan', '')); ?>" + "/" + no_req;
	  var url2 = "<?php echo e(route('post_noreq', '')); ?>" + "/" + no_req;
	  
	  	  $.ajax({
		   type:'GET',
           url:url2,
           data:{"_token": "<?php echo e(csrf_token()); ?>"},
		   dataType: "json",
           success:function(data){
			    $('#sy1').html(data);
		   }});
	  
    $('#name').html('<h3 class="modal-title">DETAIL</h3>');
    $('#ModalBody').html(
      
	  "<table><tr><td colspan=3><p><h5><u> Detail User </u></h5></p></td></tr>" +
      "<tr><td> Nama </td><td>&nbsp;:&nbsp;</td><td> <b>" + nama + "</b> </td></tr>" +
      "<tr><td> E-mail </td><td>&nbsp;:&nbsp;</td><td> <b>" + email + "</b> </td></tr>" +
      "<tr><td> No.Telp </td><td>&nbsp;:&nbsp;</td><td> <b>" + telp + "</b> </td></tr>" +
      "<tr><td> Pekerjaan </td><td>&nbsp;:&nbsp;</td><td> <b>" + pekerjaan + "</b> </td></tr>" +
      "<tr><td> Alamat </td><td>&nbsp;:&nbsp;</td><td> <b>" + alamat + "</b> </td></tr>" +
	  
      "<tr><td colspan=3><p><h5><u> Detail Permintaan </u></h5></p></td></tr>" +
      "<tr><td> No Registrasi </td><td>&nbsp;:&nbsp;</td><td> <b>" + no_req + "</b> </td></tr>" +
      "<tr><td> Department </td><td>&nbsp;:&nbsp;</td><td> <b>" + department + "</b> </td></tr>" +
      "<tr><td> Layanan/Judul </td><td>&nbsp;:&nbsp;</td><td> <b>" + layanan + "</b> </td></tr>" +
      "<tr><td> Tgl Masuk </td><td>&nbsp;:&nbsp;</td><td> <b>" + tglmasuk + "</b> </td></tr>" +
      "<tr style='box-shadow:0px 0px 1px 0.2px;'><td> Deskripsi </td><td>&nbsp;:&nbsp;</td><td> <b>" + deskripsi + "</b> </td></tr></table><br />" +
	  "<br /><p style=font-size:13px><i>" +
	  status +
	  "<br />" +
	  lastupdate +"</i></p>"
	  );
	  
	document.getElementById('userid').value = user_id;
	document.getElementById('noreq').value = no_req;
	document.getElementById('deptid').value = deptid;
	document.getElementById('deptname').value = department;
	document.getElementById('laynname').value = layanan;
    document.getElementById('postman').action = url;
	
  if(cstaff == staff ) {
	  document.getElementById('ModalEnding').style.display = 'block';
  }else if(frontdesk == '101' || (frontdesk == '104' && (staff == '2' || staff == '3'))){
	  document.getElementById('ModalEnding').style.display = 'block';
  }else{
	  document.getElementById('ModalEnding').style.display = 'none';
	  
	  if(status2 == "DIPROSES") {
		 document.getElementById('bproses').style.display = 'none';
	  }else{
		 document.getElementById('bproses').style.display = 'compact';
	  }
  }
  
  });
});

function showSyarat() {
  var x = document.getElementById("syaratUser");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
  
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ptsp.kemenag\resources\views/backend/pages/dashboard.blade.php ENDPATH**/ ?>