
<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>Data Golongan</h3>
                <p class="text-subtitle text-muted"><b>Restricted Access</b></p>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Data No Loot</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <section class="section">
	<div class="card">
            <div class="card-body">
			<h5>Cabang : <?php echo e($gmtq->golongan); ?> (kode : <?php echo e($gmtq->kode); ?>)</h5>
			<h5>Jumlah Peserta Putra <?php echo e($jmlp); ?> dari <?php echo e($gmtq->jml_p); ?></h5>
			<h5>Jumlah Peserta Putri <?php echo e($jmlw); ?> dari <?php echo e($gmtq->jml_p); ?></h5>
			<h5>Operator : <?php echo e($gmtq->user->name); ?></h5>
			</div>
	</div>
        <div class="card">
            <div class="card-body">
                <?php if(session('status')): ?>
                    <div class="alert alert-success mt-1">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <table class="table table-striped" id="table1">
                    <thead>
                        <tr>
                            <th>Peserta</th>
                            <th>Jenis Kelamin</th>
                            <th>No Loot</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $loot = str_pad($item->noloot, 3, '0', STR_PAD_LEFT); ?>
                        <tr>
                            <td><?php echo e($item->peserta); ?></td>
                            <td><?php echo e($item->jk); ?></td>
                            <td><?php echo e($gmtq->kode); ?><?php echo e($loot); ?></td>
                            <td class="d-flex">
								 <form action="<?php echo e(route('destroy.loot', Crypt::Encrypt($item->id))); ?>" onclick="return confirm('Anda Yakin Untuk Menghapus?')" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </section>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-mtq\resources\views/backend/pages/DataLoot/cekloot.blade.php ENDPATH**/ ?>