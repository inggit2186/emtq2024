<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>



<?php $__env->startSection('title','Request Layanan | Kantor Kemenag Tanah Datar'); ?>
<?php $__env->startSection('content'); ?>
<section class="w-full px-8 py-20 bg-gray-100 xl:px-8">
    <div class="max-w-5xl mt-20  mx-auto">
        <div class="flex flex-col justify-between items-center md:flex-row">
            <div class="w-full mt-16 md:mt-0 ">
                <form action="<?php echo e(route('pengaduan.store', $department->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div
                        class="w-full h-auto p-10 py-10 overflow-hidden bg-white border-b-2 border-gray-300 rounded-lg shadow-2xl px-7">
                        <h3 class="mb-6 text-2xl font-medium text-center">Request <strong>Pelayanan / Konsultasi</strong>
                        </h3>
						<label for="" class="text-gray-600">Jenis Layanan</label>
                        <div class="block mb-4 border <?php $__errorArgs = ['jenis_pengaduan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-gray-200 rounded-lg">
                            <select name="jlayanan" id="Nama"
                                class="block w-full px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none">
                                <option value="Pilihdulu" disabled selected
                                    class="block w-full px-4 py-3 border-2 border-transparent text-gray-400 rounded-lg focus:border-blue-500 focus:outline-none">
                                    ---- Silahkan Pilih Jenis Pelayanan ------</option>
								<?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value='<?php echo e($item->id); ?>' 
                                    class="block w-full px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none">
                                    <?php echo e($item->nama); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<option value="888"
                                    class="block w-full px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none">
                                    Konsultasi</option>
								<option value="999"
                                    class="block w-full px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none">
                                    Lainnya</option>
                            </select>
                        </div>
                        <?php $__errorArgs = ['jenis_pengaduan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-600 mb-4"><?php echo e($message); ?></div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					   
					   <div id="judul" style="display: none;">
                        <label for="" class="text-gray-600">Judul Permintaan / Konsultasi</label>
                        <div class="block mb-4 border border-gray-200 rounded-lg">
                            <input type="text" name="judul" id="judul_pengaduan"
                                class="block   <?php $__errorArgs = ['judul_laporan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  w-full px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none" value="<?php echo e(old('judul_laporan')); ?>"
                                placeholder="Judul Permintaan/Konsultasi">
                        </div>
                        <?php $__errorArgs = ['judul_laporan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <div class="text-red-600 mb-4"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
                        <label for="" class="text-gray-600">Nomor Induk</label>
                        <div class="block mb-4 border border-gray-200 rounded-lg">
                            <input type="number" name="user_id" id="nis"
                                class="block w-full <?php $__errorArgs = ['nomor_induk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none"  value="<?php echo e(auth()->user()->nomor_induk); ?>" readonly
                                placeholder="Nomor Induk" readonly>
                        </div>
                        <?php $__errorArgs = ['nomor_induk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-600 mb-4"><?php echo e($message); ?></div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="" class="text-gray-600">Nama</label>
                        <div class="block mb-4 border <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-gray-200 rounded-lg">
                            <input type="Nama" name="nama" id="Nama"
                                class="block w-full px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none"
                                readonly value="<?php echo e(auth()->user()->name); ?>">
                        </div>
                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-600 mb-4"><?php echo e($message); ?></div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="" class="text-gray-600">Email</label>
                        <div class="block mb-4 border <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-gray-200 rounded-lg">
                            <input type="email" name="email" id="email"
                                class="block w-full px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none"
                                readonly value="<?php echo e(auth()->user()->email); ?>">
                        </div>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-600 mb-4"><?php echo e($message); ?></div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="" class="text-gray-600">No Telp</label>
                        <div class="block mb-4 border <?php $__errorArgs = ['no_telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-gray-200 rounded-lg">
                            <input type="text" name="no_telp" id="no_telp"
                                class="block w-full px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none" 
								readonly value="<?php echo e(auth()->user()->telp); ?> ">
                        </div>
                        <?php $__errorArgs = ['no_telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-600 mb-4"><?php echo e($message); ?></div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					   <label for="" class="text-gray-600">Pekerjaan</label>
                        <div class="block mb-4 border <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-gray-200 rounded-lg">
                            <input type="pekerjaan" name="pekerjaan" id="pekerjaan"
                                class="block w-full px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none"  
								readonly value="<?php echo e(auth()->user()->pekerjaan); ?> ">
                        </div>
                        <?php $__errorArgs = ['pekerjaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-600 mb-4"><?php echo e($message); ?></div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="" class="text-gray-600">Alamat</label>
                        <div class="block mb-4 border <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-gray-200 rounded-lg">
                            <input type="alamat" name="alamat" id="alamat"
                                class="block w-full px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none"  
								readonly value="<?php echo e(auth()->user()->alamat); ?> ">
                        </div>
                        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-600 mb-4"><?php echo e($message); ?></div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="" class="text-gray-600">Tulis Deskripsi</label>
                        <div class="block mb-4 <?php $__errorArgs = ['laporan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border border-gray-200 rounded-lg">
                            <textarea name="deskripsi" id="" cols="30" rows="10"
                                class="block w-full px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none"></textarea>
                        </div>
                        <?php $__errorArgs = ['laporan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-600 mb-4"><?php echo e($message); ?></div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					   <br />
					   <br />
					   <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="layanan" id="layanan<?php echo e($row->id); ?>" style="display: none;">
							<label for="" class="text-gray-600"><strong><u>Upload Berkas Pendukung</u></strong></label><br />
							<?php $__currentLoopData = $syarat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $csyarat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($csyarat->layanan_id == $row->id): ?>
								<label for="" class="text-gray-600"><b><?php echo e($csyarat->syarat); ?></b></label>
								<div class="block mb-4  border border-gray-200 rounded-lg">
									<input type="file" accept=".pdf,.jpg,.jpeg,.png,.bmp" name="users_berkas[]" id="files"
										class="block w-full px-4 py-3 border-2 border-transparent rounded-lg focus:border-blue-500 focus:outline-none" />
								</div>
									<input type="hidden" name="filenames[]" value="<?php echo e($csyarat->syarat); ?>" />
									<input type="hidden" name="syaratid[]" value="<?php echo e($csyarat->id); ?>" />
									<input type="hidden" name="layananid[]" value="<?php echo e($csyarat->layanan_id); ?>" />
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
					   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<div class="block">
								<button type="submit"
								class="w-full px-3 py-4 font-medium font-semibold font-medium text-white bg-blue-600 rounded-lg">Kirim</button>
							</div>
                </form>
            </div>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<script>

jQuery(document).ready(function(){
  $("#Nama").change(function() {
		var layanan = $(this).val();
		var name = "layanan"+layanan;
		
      if(( layanan == "999") || ( layanan == "888")){
          $("#judul").css('display', 'block');
		  $(".layanan").css('display', 'none');
      }else{
          $("#judul").css('display', 'none');
		  var syarat = document.getElementById(name).getAttribute("id");
		  console.log(syarat);
		  $("#"+name).css('display', 'block');
		  $('.layanan').not('#' + name).css('display', 'none');
      }
	   
  });
    
});

</script>
<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ptsp.kemenag\resources\views/frontend/input-pengaduan.blade.php ENDPATH**/ ?>