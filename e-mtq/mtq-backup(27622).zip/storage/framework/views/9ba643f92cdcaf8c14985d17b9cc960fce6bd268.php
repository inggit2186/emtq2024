<!DOCTYPE html>
<html>
<head>
	<title>Laporan PDF Pengaduan SMKN 2 KARANGANYAR</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<style type="text/css">
		table tr td,
		table tr th{
			font-size: 9pt;
		}
	</style>
	<center>
		<h5>Laporan PDF Pengaduan SMKN 2 KARANGANYAR</h4>
	</center>

	<table class='table table-bordered'>
		<thead>
			<tr>
				<th>No</th>
				<th>Kode</th>
				<th>Pelapor</th>
				<th>Judul</th>
				<th>Jenis</th>
                <th>Isi Laporan</th>
                <th>Tangapan</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($loop->iteration); ?></td>
				<td><?php echo e($item->kode_pengaduan); ?></td>
				<td><?php echo e($item->nama); ?></td>
				<td><?php echo e($item->judul_laporan); ?></td>
				<td><?php echo e($item->jenis_pengaduan); ?></td>
				<td><?php echo e($item->laporan); ?></td>
				<td><?php echo e($item->tanggapan->tanggapan); ?></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

</body>
</html><?php /**PATH C:\xampp\htdocs\ptsp.kemenag\resources\views/backend/pages/pengaduan/pengaduan_pdf.blade.php ENDPATH**/ ?>