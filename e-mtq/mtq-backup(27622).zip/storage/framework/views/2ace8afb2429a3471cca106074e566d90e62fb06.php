<!DOCTYPE html>
<style>
.page-break {
    page-break-after: always;
}
</style>

<html>
<head>
	<title>Laporan Hasil Rekap Penilaian MTQ ke-41 Kab.Tanah Datar</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<style type="text/css">
	table {
          border-collapse: collapse;
        }
		table tr td,
		table tr th{
			font-size: 9pt;
			text-align:center;
			vertical-align: center;
		}
	</style>
	<center>
		<h4>Laporan Hasil Rekap Penilaian MTQ ke-41 Kab.Tanah Datar</h4>
	</center>
	<br />
	<br />
	<?php $nox=1; ?>
	<?php $__currentLoopData = $gmtq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gmtq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<p><strong><i><?php echo e($nox); ?>.<?php echo e($gmtq->golongan); ?></i></strong></p>
	<table class='table table-bordered'>
		<thead>
			<tr>
				<th>No</th>
				<th>NoLoot</th>
				<th>JK</th>
				<th>Peserta</th>
				<th>Utusan</th>
				<th>Nilai</th>
			</tr>
		</thead>
		<tbody>
			<?php 
				$peserta = App\Models\Peserta::with(['cmtq','gmtq'])->where('golongan_id',$gmtq->id)->orderBy('total', 'DESC')->orderBy('id', 'ASC')->get();
				$i=1;
			?>
			<?php 
				$peserta2 = App\Models\Peserta::with(['cmtq','gmtq'])->where('golongan_id',$gmtq->id)->orderBy('total', 'DESC')->orderBy('id', 'ASC')->get();
				$w=1;
			?>
			<?php $__currentLoopData = $peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($peserta->jk == "Putra"): ?>
			<?php if($i < 4): ?>
			<tr>
				<td><?php echo e($i); ?></td>
				<td><?php echo e($peserta->nomor); ?></td>
				<td><?php echo e($peserta->jk); ?></td>
				<td><?php echo e($peserta->nama); ?></td>
				<td><?php echo e($peserta->utusan); ?></td>
				<td><?php echo e($peserta->total); ?></td>
			<?php $i++; ?>
			</tr>
			<?php endif; ?>
			<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
			<?php $__currentLoopData = $peserta2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peserta2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($peserta2->jk == "Putri"): ?>
			<?php if($w < 4): ?>
			<tr style="background-color:#2DFFFF;">
				<td><?php echo e($w); ?></td>
				<td><?php echo e($peserta2->nomor); ?></td>
				<td><?php echo e($peserta2->jk); ?></td>
				<td><?php echo e($peserta2->nama); ?></td>
				<td><?php echo e($peserta2->utusan); ?></td>
				<td><?php echo e($peserta2->total); ?></td>
			<?php $w++; ?>
			</tr>
			<?php endif; ?>
			<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<br />
	<?php $nox++; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH /home/kemenagt/public_html/mtq/resources/views/backend/pages/layanan/nilai2_pdf.blade.php ENDPATH**/ ?>