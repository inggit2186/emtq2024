

<?php $__env->startSection('title', 'Sub-Bagian | Kantor KEMENAG Tanah Datar'); ?>
<?php $__env->startSection('content'); ?>


<style>
@import  url('https://fonts.googleapis.com/css?family=Kanit|Lobster');

html {
  font-family: 'Kanit', sans-serif;
}

.body2 {
  padding-top: 120px;
  background-color: #fff;
  color: #000;
  display: flex;
  align-items: center;
  min-height: 100vh;
}

.container {
  width: 90%;
  margin: 0 auto;
}

.container > h1, .title {
  font-family: 'Lobster', cursive;
  letter-spacing: 1px;
  font-size: 35px;
}

.container > h1, .container > p {
    text-align: center;
 }

.services {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  margin-top: 40px;
}

.service {
  margin: 10px;
  overflow: hidden;
  padding: 35px 15px;
  position: relative;
  text-align: center;
  transition: background-color 0.3s ease-in,
              transform .3s ease-in;
  width: 200px;
}

.service:hover {
  background-color: #8e44ad;
  transform: translateY(-3px);
}

.service::before {
  content: '';
  border-width: 20px;
  border-style: solid;
  border-color: #222f3e #222f3e rgba(1,1,1,0.4) rgba(0,0,0,0.4);
  position: absolute;
  right: -40px;
  top: -40px;
  transition: right 0.3s ease-out,
                top 0.3s ease-out;
}

.service:hover::before {
  right: 0;
  top: 0;
}

.service > i {
  display: block;
  color: #8e44ad;
  font-size: 4rem;
  margin-bottom: 0.9rem;
  transition: color 0.3s ease-out;
}

.service > .title {
  font-weight: 900;
  font-size: 1.2rem;
  line-height: 1.56rem;
  margin-bottom: 1rem;
  text-transform: capitalize;
  transition: color 0.3s ease-out;
}

.service > .description {
  line-height: 1.56rem;
  margin: 0;
  transition: color 0.3s ease-out;
}

.service:hover > i,
.service:hover > .title,
.service:hover > .description {
  color: #FFF;
}
</style>
<html>

<div class="body2">
<div class="container">
  <h1>Kategori MTQ</h1>
  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt, quasi? Reiciendis eius autem officiis <br>
    totam dolorem quibusdam reprehenderit nulla iste.</p>
  <div class="services">
    
	<?php $__currentLoopData = $cmtq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<a href="<?php echo e(route('buat.layanan', Crypt::Encrypt($item->id))); ?>">
	<div class="service">
     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 940 812"><path d="M0 480c0 17.67 14.33 32 32 32h64c17.67 0 32-14.33 32-32V160H0v320zm579.16-192c17.86-17.39 28.84-37.34 28.84-58.91 0-52.86-41.79-93.79-87.92-122.9-41.94-26.47-80.63-57.77-111.96-96.22L400 0l-8.12 9.97c-31.33 38.45-70.01 69.76-111.96 96.22C233.79 135.3 192 176.23 192 229.09c0 21.57 10.98 41.52 28.84 58.91h358.32zM608 320H192c-17.67 0-32 14.33-32 32v128c0 17.67 14.33 32 32 32h32v-64c0-17.67 14.33-32 32-32s32 14.33 32 32v64h64v-72c0-48 48-72 48-72s48 24 48 72v72h64v-64c0-17.67 14.33-32 32-32s32 14.33 32 32v64h32c17.67 0 32-14.33 32-32V352c0-17.67-14.33-32-32-32zM64 0S0 32 0 96v32h128V96c0-64-64-96-64-96z"/></svg>
      <h4 class="title"><?php echo e($item->kategori); ?></h4>
      <p class="description">
			 Kategori MTQ Kab.Tanah Datar
      </p>
    </div>
	</a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
  </div>
</div>
</div>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mtq.kemenag\resources\views/frontend/subbagian.blade.php ENDPATH**/ ?>