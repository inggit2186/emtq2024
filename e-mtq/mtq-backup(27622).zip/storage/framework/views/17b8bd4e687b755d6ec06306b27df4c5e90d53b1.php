<!DOCTYPE html>
<style>
.page-break {
    page-break-after: always;
}
</style>

<html>
<head>
	<title>Laporan Hasil Rekap Penilaian MTQ ke-41 Kab.Tanah Datar</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<style type="text/css">
		table tr td,
		table tr th{
			font-size: 9pt;
			text-align:center;
			vertical-align: center;
		}
	</style>
	<center>
		<h4>Laporan Hasil Rekap Penilaian MTQ ke-41 Kab.Tanah Datar</h4>
	</center>
	<br />
	<br />
	<?php $__currentLoopData = $gmtq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gmtq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<center>
		<h5><?php echo e($gmtq->golongan); ?></h5>
	</center>
	<table class='table table-bordered'>
		<thead>
			<tr>
				<th rowspan=2>No</th>
				<th rowspan=2>NoLoot</th>
				<th rowspan=2>Peserta</th>
				<?php if($cmtq->id == 7): ?>
				  <th rowspan=2>Nomor Tampil</th>
				<?php endif; ?>
				<?php if($cmtq->penanya == 1): ?>
				<th rowspan=2>Hakim Penanya</th>
				<?php endif; ?>
				<?php $bidang = App\Models\Bidang::with('cmtq')->where('cat_id',$cmtq->id)->get(); ?>
				<?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bidang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<th colspan=<?php echo e($bidang->hakim); ?>><?php echo e($bidang->nama); ?></th>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<th rowspan=2>Nilai</th>
				<th rowspan=2>Operator</th>
			</tr>
			<tr>
				<?php $bidang2 = App\Models\Bidang::with('cmtq')->where('cat_id',$cmtq->id)->get(); ?>
				<?php $__currentLoopData = $bidang2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bidang2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php for($a=1 ; $a<= $bidang->hakim ; $a++): ?>
					<th>Hakim <?php echo e($a); ?></th>
				<?php endfor; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tr>
		</thead>
		<tbody>
			<?php 
				$peserta = App\Models\Peserta::with(['cmtq','gmtq'])->where('golongan_id',$gmtq->id)->orderBy('total', 'DESC')->orderBy('id', 'ASC')->get();
				$i=1;
			?>
			<?php 
				$peserta2 = App\Models\Peserta::with(['cmtq','gmtq'])->where('golongan_id',$gmtq->id)->orderBy('total', 'DESC')->orderBy('id', 'ASC')->get();
				$w=1;
			?>
			<?php $__currentLoopData = $peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($peserta->jk == "Putra"): ?>
			<tr>
				<td><?php echo e($i); ?></td>
				<td><?php echo e($peserta->nomor); ?></td>
				<td><?php echo e($peserta->nama); ?></td>
				<?php if($cmtq->id == 7): ?>
				<td style="text-align: center;"><?php echo e($peserta->nomor); ?></td>
				<?php endif; ?>
				<?php if($cmtq->penanya == 1): ?>
					<?php $penanya = App\Models\Nilai::where(['peserta' => $peserta->nama, 'status' => 0])->first(); ?>
					<?php if(!empty($penanya)): ?>
					<td><?php echo e($penanya->penanya); ?></td>
					<?php endif; ?>
				<?php endif; ?>
				
				<?php $bidang3 = App\Models\Bidang::with('cmtq')->where('cat_id',$cmtq->id)->get(); ?>
				<?php $__currentLoopData = $bidang3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bidang3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php $nilai = App\Models\Nilai::with(['cmtq','gmtq','bidang','peserta'])->where(['peserta' => $peserta->nama,'status' => 0, 'bidang_id' => $bidang3->id])->get(); ?>
					<?php $__currentLoopData = $nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($nilai->nilai != NULL): ?>
					<td>(<?php echo e($nilai->nilai); ?>)<br /><?php echo e($nilai->hakim); ?></td>
					<?php else: ?>
					<td><i>-</i></td>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<td><?php echo e($peserta->total); ?></td>
				<td><?php echo e($peserta->operator); ?></td>
			<?php $i++; ?>
			</tr>
			<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php $__currentLoopData = $peserta2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peserta2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($peserta2->jk == "Putri"): ?>
			<tr style="background-color:#00F2F2">
				<td><?php echo e($w); ?></td>
				<td><?php echo e($peserta2->nomor); ?></td>
				<td><?php echo e($peserta2->nama); ?></td>
				<?php if($cmtq->id == 7): ?>
				<td style="text-align: center;"><?php echo e($peserta2->nomor); ?></td>
				<?php endif; ?>
				<?php if($cmtq->penanya == 1): ?>
					<?php $penanya = App\Models\Nilai::where('peserta',$peserta2->nama)->first(); ?>
					<?php if(!empty($penanya)): ?>
					<td><?php echo e($penanya->penanya); ?></td>
					<?php endif; ?>
				<?php endif; ?>
				
				<?php $bidang3 = App\Models\Bidang::with('cmtq')->where('cat_id',$cmtq->id)->get(); ?>
				<?php $__currentLoopData = $bidang3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bidang3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php $nilai2 = App\Models\Nilai::with(['cmtq','gmtq','bidang','peserta'])->where(['peserta' => $peserta2->nama,'bidang_id' => $bidang3->id])->get(); ?>
					<?php $__currentLoopData = $nilai2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($nilai2->nilai != NULL): ?>
					<td>(<?php echo e($nilai2->nilai); ?>)<br /><?php echo e($nilai2->hakim); ?></td>
					<?php else: ?>
					<td><i>-</i></td>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<td><?php echo e($peserta2->total); ?></td>
				<td><?php echo e($peserta2->operator); ?></td>
			<?php $w++; ?>
			</tr>
			<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<br />
	<br />
	<div class="page-break"></div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH /home/kemenagt/public_html/mtq/resources/views/backend/pages/layanan/nilai_pdf.blade.php ENDPATH**/ ?>