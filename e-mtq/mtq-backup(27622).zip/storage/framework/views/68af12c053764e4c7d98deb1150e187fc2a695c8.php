<!DOCTYPE html>
<style>
.page-break {
    page-break-after: always;
}
</style>

<html>
<head>
	<title>Laporan Hasil Rekap Penilaian MTQ ke-41 Kab.Tanah Datar</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<style type="text/css">
		table tr td,
		table tr th{
			font-size: 9pt;
			text-align:center;
			vertical-align: center;
		}
	</style>
	<center>
		<h4>Laporan Hasil Rekap Penilaian MTQ ke-41 Kab.Tanah Datar</h4>
		<h5><?php echo e($cmtq->kategori); ?></h5>
	</center>
	<br />
	<br />
	<table class='table table-bordered'>
		<thead>
			<tr>
				<th>No</th>
				<th>Cabang</th>
				<th>NoLoot</th>
				<th>Nama</th>
				<th>Utusan</th>
				<th>TOTAL</th>
			</tr>
		</thead>
		<tbody>
		    <?php $__currentLoopData = $peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    <tr>
		        <td>1</td>
		        <td><?php echo e($peserta->gmtq->golongan); ?></td>
		        <td><?php echo e($peserta->nomor); ?></td>
		        <td><?php echo e($peserta->nama); ?></td>
		        <td><?php echo e($peserta->utusan); ?></td>
		        <td><?php echo e($peserta->total); ?></td>

		    </tr>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<br />
	<br />
	<div class="page-break"></div>
	

</body>
</html><?php /**PATH /home/kemenagt/public_html/mtq/resources/views/backend/pages/layanan/finalis_pdf.blade.php ENDPATH**/ ?>