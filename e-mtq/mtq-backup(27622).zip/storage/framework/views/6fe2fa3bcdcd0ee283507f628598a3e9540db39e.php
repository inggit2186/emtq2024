
<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>Data Cabang</h3>
                <p class="text-subtitle text-muted">For user to check cabang MTQ</p>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Data Cabang</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <section class="section">
        <div class="card">
            <div class="card-body">
                <a href="<?php echo e(route('create.cabang')); ?>" class="btn btn-primary">Tambah</a>
                <?php if(session('status')): ?>
                    <div class="alert alert-success mt-1">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <table class="table table-striped" id="table1">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Penanya</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cmtq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->kategori); ?></td>
                            <td><?php if($item->penanya == 0): ?> No <?php else: ?> Yes <?php endif; ?></td>
                            <td class="d-flex">
								<a href="<?php echo e(route('data.golongan', Crypt::Encrypt($item->id))); ?>" class="btn btn-sm btn-success"><i class="fas fa-list"></i></a>
                                &nbsp;<a href="<?php echo e(route('edit.cabang', Crypt::Encrypt($item->id))); ?>" class="btn btn-sm btn-info"><i class="fas fa-edit"></i></a>
                                &nbsp;<form action="<?php echo e(route('destroy.cabang', Crypt::Encrypt($item->id))); ?>" onclick="return confirm('Anda Yakin Untuk Menghapus?')" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </section>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\e-mtq\resources\views/backend/pages/DataCabang/index.blade.php ENDPATH**/ ?>