<!DOCTYPE html>
<style>
.page-break {
    page-break-after: always;
}
.xheader {
    font-size:22px;
    font-family: 'Monaco', monospace;
    text-align:center;
}
</style>

<html>
<head>
	<title>Rekap Hasil MTQ Nasional Ke-41 Cabang Kab.Tanah Datar</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<style type="text/css">
	table {
          border-collapse: collapse;
        }
        table tr td,
		table tr th{
			font-size: 9pt;
			text-align:center;
			vertical-align: center;
		}
	</style>
	<center>
		<p class="xheader"><strong>Lampiran Keputusan Koordinator Dewan Hakim</strong><br /><span style="font-size:15px;">No:<i>&nbsp;&nbsp;&nbsp;/KPTS/DH/MTQ/XLI/2022</i> Tanggal <i>24 Juni 2022</i> <br />Tentang Penetapan Juara I,II,III dan Harapan I,II,III <br/> MTQ Nasional <i>Ke-XLI</i> Tingkat Kabupaten Tanah Datar <br />Tahun 2022</span></p>
	</center>
	<?php $nox=1; ?>
	<?php $__currentLoopData = $gmtq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gmtq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<p><strong><i><?php echo e($nox); ?>.<?php echo e($gmtq->golongan); ?></i></strong></p>
	<table class='table table-bordered'>
		<thead>
			<tr style="border-bottom:2pt solid black">
				<th>No</th>
				<th>NoLoot</th>
				<th>JK</th>
				<th>Peserta</th>
				<th>Utusan</th>
				<th>Nilai</th>
			</tr>
		</thead>
		<tbody>
			<?php
			    if($gmtq->id == 18){
			    $pesertap = App\Models\Peserta::with(['cmtq','gmtq'])->where(['golongan_id' => $gmtq->id,'jk' => "Putra"])->orderBy('total', 'DESC')->orderBy('id', 'ASC')->take(3)->get();
			    }else{
				$pesertap = App\Models\PesertaFinal::with(['cmtq','gmtq'])->where(['golongan_id' => $gmtq->id,'jk' => "Putra"])->orderBy('total', 'DESC')->orderBy('id', 'ASC')->take(3)->get();
				};
				$harapanp = App\Models\Peserta::with(['cmtq','gmtq'])->where(['golongan_id' => $gmtq->id,'jk' => "Putra"])->orderBy('total', 'DESC')->orderBy('id', 'ASC')->skip(3)->take(3)->get();
				$i=1;
			?>
			<?php 
			    if($gmtq->id == 18){
			    $pesertaw = App\Models\Peserta::with(['cmtq','gmtq'])->where(['golongan_id' => $gmtq->id,'jk' => "Putri"])->orderBy('total', 'DESC')->orderBy('id', 'ASC')->take(3)->get();
			    }else{
				$pesertaw = App\Models\PesertaFinal::with(['cmtq','gmtq'])->where(['golongan_id' => $gmtq->id,'jk' => "Putri"])->orderBy('total', 'DESC')->orderBy('id', 'ASC')->take(3)->get();
				};
				$harapanw = App\Models\Peserta::with(['cmtq','gmtq'])->where(['golongan_id' => $gmtq->id,'jk' => "Putri"])->orderBy('total', 'DESC')->orderBy('id', 'ASC')->skip(3)->take(3)->get();
				$w=1;
			?>
			<?php $__currentLoopData = $pesertap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesertap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr style="border-bottom: 1pt solid black;">
				<td>Juara <?php echo e($i); ?></td>
				<td><?php echo e($pesertap->nomor); ?></td>
				<td><?php echo e($pesertap->jk); ?></td>
				<td><?php echo e($pesertap->nama); ?></td>
				<td><?php echo e($pesertap->utusan); ?></td>
				<td><?php echo e($pesertap->total); ?> (f)</td>
			<?php $i++; ?>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php $i=1; ?>
		    <?php $__currentLoopData = $harapanp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $harapanp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr style="background-color:#7AFFFF; <?php if($i==3): ?>border-bottom: 2pt solid black; <?php else: ?> border-bottom: 1pt solid black; <?php endif; ?>" >
				<td>Harapan <?php echo e($i); ?></td>
				<td><?php echo e($harapanp->nomor); ?></td>
				<td><?php echo e($harapanp->jk); ?></td>
				<td><?php echo e($harapanp->nama); ?></td>
				<td><?php echo e($harapanp->utusan); ?></td>
				<td><?php echo e($harapanp->total); ?></td>
			<?php $i++; ?>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
			<?php $__currentLoopData = $pesertaw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesertaw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr style="background-color:#2DFFFF;border-bottom:1pt solid black">
				<td>Juara <?php echo e($w); ?></td>
				<td><?php echo e($pesertaw->nomor); ?></td>
				<td><?php echo e($pesertaw->jk); ?></td>
				<td><?php echo e($pesertaw->nama); ?></td>
				<td><?php echo e($pesertaw->utusan); ?></td>
				<td><?php echo e($pesertaw->total); ?> (f)</td>
			<?php $w++; ?>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php $w=1; ?>
		    <?php $__currentLoopData = $harapanw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $harapanw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr style="background-color:#00E5E5; <?php if($w==3): ?>border-bottom: 2pt solid black; <?php else: ?> border-bottom: 1pt solid black; <?php endif; ?>">
				<td>Harapan <?php echo e($w); ?></td>
				<td><?php echo e($harapanw->nomor); ?></td>
				<td><?php echo e($harapanw->jk); ?></td>
				<td><?php echo e($harapanw->nama); ?></td>
				<td><?php echo e($harapanw->utusan); ?></td>
				<td><?php echo e($harapanw->total); ?></td>
			<?php $w++; ?>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<br />
	<?php $nox++; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
<br /><br />
<footer>
    <div>
         <img src="<?php echo e(asset('assets/etc/ttd.png')); ?>" style="align:center;"/>
    </div>
</footer>
</html><?php /**PATH /home/kemenagt/public_html/mtq/resources/views/backend/pages/layanan/nilai2final_pdf.blade.php ENDPATH**/ ?>