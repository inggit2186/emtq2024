<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Surat extends Model
{
    protected $table = 'ktd_surat';

    protected $fillable = [
		'no_surat',
        'user_id',
        'dept_id',
        'penerima',
        'perihal',
        'keterangan',
        'surat',
        'lampiran1',
        'lampiran2',
        'created_at',
        'updated_at'
    ];
	
	public function user(){
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
	public function dept(){
        return $this->belongsTo(Department::class, 'dept_id', 'id');
    }
}
